import express from 'express';
import * as usersController from '../controllers/users.controller.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// Require authentication for all user routes
router.use(authenticate);

// Update current user's GitHub username
router.patch('/profile/github', usersController.updateMyGithubUsername);

// Get users list (Admin and Teacher only)
router.get('/', authorize('admin', 'teacher'), usersController.getUsers);

// Get user by ID (admin: any user; teacher: own profile or their assigned students; student: own profile only — enforced in the controller)
router.get(
  '/:id',
  usersController.getUserById
);
// Admin-only user management
router.post('/', authorize('admin'), usersController.createUser);
router.post('/import-students', authorize('admin'), usersController.importStudents);
router.post('/import-students/excel', authorize('admin'), usersController.importStudentsFile);
router.put('/:id', authenticate, usersController.updateUser);
router.delete('/:id', authorize('admin'), usersController.deleteUser);

export default router;