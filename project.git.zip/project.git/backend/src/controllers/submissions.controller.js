import { pool } from '../config/db.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { analyzeSubmissionWithGemini } from '../services/ai.service.js';
import { teacherOwnsGroup } from '../utils/scope.js';

// NOTE on github_repo_url vs github_url:
// The DB column is `github_url` (see assessment_submissions in 01_schema_v2.sql).
// TeacherSubmissions.tsx / TeacherAIEvaluations.tsx were written against a
// `github_repo_url` field name. Rather than touching every frontend call site,
// we alias the column so both names are present on every row.

export const getAllSubmissions = asyncHandler(async (req, res) => {
  const { assessment_id, student_id } = req.query;
  let q = `SELECT s.*, s.github_url AS github_repo_url,
                  u.name student_name, u.email student_email, u.github_username,
                  su.name AS submitted_by_name,
                  a.title assessment_title, a.max_score assessment_max_score, a.group_id,
                  latest_eval.total_ai_score AS ai_score,
                  latest_eval.total_teacher_score AS final_score,
                  latest_eval.status AS ai_evaluation_status
           FROM assessment_submissions s
           LEFT JOIN users u ON u.id = s.student_id
           LEFT JOIN users su ON su.id = s.submitted_by
           JOIN assessments a ON a.id = s.assessment_id
           LEFT JOIN ai_evaluations latest_eval
             ON latest_eval.id = (
               SELECT ae.id
               FROM ai_evaluations ae
               WHERE ae.submission_id = s.id
               ORDER BY ae.id DESC
               LIMIT 1
             )
           WHERE 1=1`;
  const p = [];
  if (req.user.role === 'student') {
    q += ' AND s.student_id=?';
    p.push(req.user.sub);
  } else {
    // A teacher only ever sees submissions for assessments that belong to
    // one of their own assigned groups (proposal §4).
    if (req.user.role === 'teacher') {
      q += ' AND EXISTS (SELECT 1 FROM group_teachers gt WHERE gt.group_id = a.group_id AND gt.teacher_id = ?)';
      p.push(req.user.sub);
    }
    if (student_id) {
      q += ' AND s.student_id=?';
      p.push(student_id);
    }
  }
  if (assessment_id) {
    q += ' AND s.assessment_id=?';
    p.push(assessment_id);
  }
  q += ' ORDER BY s.id DESC';
  const [rows] = await pool.query(q, p);
  res.json({ success: true, count: rows.length, data: rows });
});
export const getSubmissions = getAllSubmissions;

export const getSubmissionById = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const [rows] = await pool.query(
    `SELECT s.*, s.github_url AS github_repo_url,
            u.name student_name, u.email student_email, u.github_username,
            su.name AS submitted_by_name,
            a.title assessment_title, a.description assessment_description, a.max_score assessment_max_score,
            a.group_id assessment_group_id
     FROM assessment_submissions s
     LEFT JOIN users u ON u.id = s.student_id
     LEFT JOIN users su ON su.id = s.submitted_by
     JOIN assessments a ON a.id = s.assessment_id
     WHERE s.id = ?`,
    [id]
  );
  if (!rows.length) throw new ApiError(404, 'Submission not found');
  const submission = rows[0];

  const isTeacherOrAdmin = req.user.role === 'teacher' || req.user.role === 'admin';

  // A student may only ever view their own submission.
  if (req.user.role === 'student' && submission.student_id !== req.user.sub) {
    throw new ApiError(403, 'You do not have access to this submission');
  }

  // A teacher may only view submissions belonging to a group they are
  // actually assigned to (proposal §4).
  if (req.user.role === 'teacher' && !(await teacherOwnsGroup(req.user.sub, submission.assessment_group_id))) {
    throw new ApiError(403, 'You do not have access to this submission');
  }

  // All evaluation attempts for this submission, most recent first.
  const [evals] = await pool.query(
    `SELECT ae.*, u.name reviewed_by_name
     FROM ai_evaluations ae LEFT JOIN users u ON u.id = ae.reviewed_by
     WHERE ae.submission_id = ? ORDER BY ae.id DESC`,
    [id]
  );
  const latestEval = evals[0] || null;
let competencySuggestions = [];

if (latestEval) {
  const [suggestions] = await pool.query(
    `SELECT
       acs.id,
       acs.competency_id,
       c.name AS competency_name,
       acs.current_score,
       acs.suggested_score,
       acs.reason
     FROM ai_competency_suggestions acs
     JOIN competencies c ON c.id = acs.competency_id
     WHERE acs.ai_evaluation_id = ?
     ORDER BY c.name`,
    [latestEval.id]
  );

  competencySuggestions = suggestions;
}
  if (isTeacherOrAdmin) {
    // ---- TEACHER / ADMIN VIEW: full AI draft + teacher-edited detail ----
    const [scores] = latestEval
      ? await pool.query(
          `SELECT cs.id, cs.criterion_id, ac.name criterion_name, ac.description criterion_description,
                  ac.max_score criterion_max_score,
                  cs.ai_recommended_score, cs.ai_recommended_score AS ai_score, cs.ai_rationale,
                  cs.teacher_final_score,
                  (cs.teacher_final_score IS NOT NULL AND cs.teacher_final_score <> cs.ai_recommended_score) AS teacher_override
           FROM criterion_scores cs
           JOIN assessment_criteria ac ON ac.id = cs.criterion_id
           WHERE cs.ai_evaluation_id = ?
           ORDER BY ac.sort_order, ac.id`,
          [latestEval.id]
        )
      : [[]];

    return res.json({
      success: true,
      data: {
        ...submission,
        // Flat compatibility fields (consumed by TeacherAIEvaluations.tsx)
        ai_evaluation_id: latestEval?.id ?? null,
        ai_evaluation_status: latestEval?.status ?? null,
        ai_score: latestEval?.total_ai_score ?? null,
        final_score: latestEval?.total_teacher_score ?? null,
        teacher_feedback: latestEval?.teacher_comment ?? null,
        strengths: latestEval?.strengths ?? null,
        areas_for_improvement: latestEval?.areas_for_improvement ?? null,
        recommendations: latestEval?.recommendations ?? null,
        suggested_next_steps: latestEval?.suggested_next_steps ?? null,
        criteria_scores: scores,
        competency_suggestions: competencySuggestions,
        // Nested full history (consumed by StudentSubmissions-style shape / future clients)
        ai_evaluations: evals,
      },
    });
  }

  // ---- STUDENT VIEW: only approved/final teacher-reviewed content ----
  const approvedEval = evals.find((e) => e.status === 'approved') || null;
  const rejectedEval = !approvedEval ? evals.find((e) => e.status === 'rejected') : null;

  let studentEvaluations = [];
  let studentCriteria = [];

  if (approvedEval) {
    studentEvaluations = [
      {
        id: approvedEval.id,
        status: 'approved',
        total_teacher_score: approvedEval.total_teacher_score,
        strengths: approvedEval.strengths,
        areas_for_improvement: approvedEval.areas_for_improvement,
        recommendations: approvedEval.recommendations,
        suggested_next_steps: approvedEval.suggested_next_steps,
        teacher_comment: approvedEval.teacher_comment,
        reviewed_by_name: approvedEval.reviewed_by_name,
        reviewed_at: approvedEval.reviewed_at,
      },
    ];
    const [approvedScores] = await pool.query(
      `SELECT cs.id, cs.criterion_id, ac.name criterion_name, ac.max_score criterion_max_score,
              cs.teacher_final_score
       FROM criterion_scores cs
       JOIN assessment_criteria ac ON ac.id = cs.criterion_id
       WHERE cs.ai_evaluation_id = ?
       ORDER BY ac.sort_order, ac.id`,
      [approvedEval.id]
    );
    // ai_recommended_score is intentionally omitted (null) — students never see AI draft scores.
    studentCriteria = approvedScores.map((s) => ({ ...s, ai_recommended_score: null }));
  } else if (rejectedEval) {
    studentEvaluations = [
      {
        id: rejectedEval.id,
        status: 'rejected',
        total_teacher_score: null,
        teacher_comment: rejectedEval.teacher_comment,
        reviewed_by_name: rejectedEval.reviewed_by_name,
        reviewed_at: rejectedEval.reviewed_at,
      },
    ];
  }
  // If neither approved nor rejected exists yet (submitted/analyzing/ai_reviewed/
  // teacher_reviewed-in-progress), studentEvaluations stays empty — the student
  // sees only the generic "being reviewed" pending state, never AI draft internals.

  res.json({
    success: true,
    data: {
      id: submission.id,
      status: submission.status,
      github_url: submission.github_url,
      submitted_at: submission.submitted_at,
      submitted_by_name: submission.submitted_by_name,
      assessment_max_score: submission.assessment_max_score,
      ai_evaluations: studentEvaluations,
      criteria_scores: studentCriteria,
    },
  });
});

export const createSubmission = asyncHandler(async (req, res) => {
  const {
    assessment_id,
    github_repo_url,
    github_url,
  } = req.body;

  const student_id = req.user.sub;
  const url = (github_url || github_repo_url || '').trim();

  if (!assessment_id || !url) {
    throw new ApiError(
      400,
      'Assessment ID and GitHub repository URL are required'
    );
  }

  const [a] = await pool.query(
    'SELECT * FROM assessments WHERE id=?',
    [assessment_id]
  );

  if (!a.length) {
    throw new ApiError(404, 'Assessment not found');
  }

  // ---------------------------------------------------------
  // Resolve GitHub repository and CURRENT COMMIT SHA
  // ---------------------------------------------------------
  let owner;
  let repo;
  let commitSha;

  try {
    const u = new URL(url);
    const parts = u.pathname
      .split('/')
      .filter(Boolean);

    if (parts.length < 2) {
      throw new ApiError(
        400,
        'Invalid GitHub repository URL'
      );
    }

    owner = parts[0];
    repo = parts[1].replace(/\.git$/, '');

    const githubHeaders = process.env.GITHUB_TOKEN
      ? {
          Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
          Accept: 'application/vnd.github+json',
        }
      : {
          Accept: 'application/vnd.github+json',
        };

    // Get repository information first.
    const repoResponse = await fetch(
      `https://api.github.com/repos/${owner}/${repo}`,
      {
        headers: githubHeaders,
      }
    );

    if (!repoResponse.ok) {
      throw new ApiError(
        400,
        `Could not access GitHub repository (status ${repoResponse.status})`
      );
    }

    const repoData = await repoResponse.json();
    const defaultBranch = repoData.default_branch;

    if (!defaultBranch) {
      throw new ApiError(
        400,
        'Could not determine GitHub default branch'
      );
    }

    // Get the EXACT latest commit SHA of the default branch.
    const branchResponse = await fetch(
      `https://api.github.com/repos/${owner}/${repo}/commits/${encodeURIComponent(defaultBranch)}`,
      {
        headers: githubHeaders,
      }
    );

    if (!branchResponse.ok) {
      throw new ApiError(
        400,
        `Could not determine repository commit (status ${branchResponse.status})`
      );
    }

    const branchData = await branchResponse.json();

    commitSha = branchData.sha;

    if (!commitSha) {
      throw new ApiError(
        400,
        'Could not determine GitHub commit SHA'
      );
    }

    console.log(
      `[Submission] GitHub snapshot resolved: ${owner}/${repo} @ ${commitSha}`
    );
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }

    console.error(
      '[Submission] GitHub repository resolution failed:',
      error.message
    );

    throw new ApiError(
      400,
      'Could not access the GitHub repository'
    );
  }

  // ---------------------------------------------------------
  // Create / update submission
  // ---------------------------------------------------------

  const assessment = a[0];
  const isTeamAssessment = assessment.submission_mode === 'team';

  let id;
  // For team assessments, every teammate needs their OWN
  // assessment_submissions row (student_id is required and mutually
  // exclusive with team_id per chk_submission_owner), all pointing at the
  // same repo/commit, so each of them sees the submission on their own
  // dashboard. `siblingIds` collects every row so a single Gemini call can
  // be fanned out identically to the whole team instead of each teammate
  // silently getting no evaluation (or, if they each submitted separately,
  // getting a different, inconsistent AI evaluation of the same code).
  let siblingIds = null;

  if (isTeamAssessment) {
    const [team] = await pool.query(
      `SELECT t.id
       FROM teams t
       JOIN team_members tm ON tm.team_id = t.id
       WHERE t.group_id = ? AND tm.student_id = ?
       LIMIT 1`,
      [assessment.group_id, student_id]
    );

    if (!team.length) {
      throw new ApiError(400, 'You are not part of a team for this assessment');
    }

    const [members] = await pool.query(
      'SELECT student_id FROM team_members WHERE team_id = ?',
      [team[0].id]
    );

    siblingIds = [];

    for (const member of members) {
      const memberId = member.student_id;

      const [existingMember] = await pool.query(
        `SELECT id
         FROM assessment_submissions
         WHERE assessment_id=? AND student_id=?`,
        [assessment_id, memberId]
      );

      let memberSubmissionId;

      if (existingMember.length) {
        memberSubmissionId = existingMember[0].id;

        await pool.query(
          `UPDATE assessment_submissions
           SET github_url=?,
               commit_sha=?,
               submitted_by=?,
               status='analyzing',
               submitted_at=NOW(),
               analyzed_at=NULL,
               ai_score=NULL,
               ai_feedback=NULL
           WHERE id=?`,
          [url, commitSha, student_id, memberSubmissionId]
        );
      } else {
        const [r] = await pool.query(
          `INSERT INTO assessment_submissions
           (
             assessment_id,
             student_id,
             submitted_by,
             github_url,
             commit_sha,
             status
           )
           VALUES (?, ?, ?, ?, ?, 'analyzing')`,
          [assessment_id, memberId, student_id, url, commitSha]
        );

        memberSubmissionId = r.insertId;
      }

      siblingIds.push(memberSubmissionId);
      if (Number(memberId) === Number(student_id)) id = memberSubmissionId;
    }

    // Defensive fallback: should always be set since the team lookup above
    // already confirmed `student_id` is a member of `team`.
    if (!id) id = siblingIds[0];
  } else {
    const [existing] = await pool.query(
      `SELECT id
       FROM assessment_submissions
       WHERE assessment_id=? AND student_id=?`,
      [assessment_id, student_id]
    );

    if (existing.length) {
      id = existing[0].id;

      await pool.query(
        `UPDATE assessment_submissions
         SET github_url=?,
             commit_sha=?,
             status='analyzing',
             submitted_at=NOW(),
             analyzed_at=NULL,
             ai_score=NULL,
             ai_feedback=NULL
         WHERE id=?`,
        [
          url,
          commitSha,
          id,
        ]
      );
    } else {
      const [r] = await pool.query(
        `INSERT INTO assessment_submissions
         (
           assessment_id,
           student_id,
           github_url,
           commit_sha,
           status
         )
         VALUES (?, ?, ?, ?, 'analyzing')`,
        [
          assessment_id,
          student_id,
          url,
          commitSha,
        ]
      );

      id = r.insertId;
    }
  }

  // ---------------------------------------------------------
  // Start AI analysis using the EXACT commit
  // ---------------------------------------------------------

  try {
    if (owner && repo && commitSha) {
      analyzeSubmissionWithGemini(
        id,
        owner,
        repo,
        commitSha,
        siblingIds || undefined
      ).catch((e) => {
        console.error(
          `[AI Service Error] submission ${id}:`,
          e.message
        );
      });
    }
  } catch (e) {
    console.error(
      `[AI Service Error] submission ${id}:`,
      e.message
    );
  }

  res.status(201).json({
    success: true,
    message: 'Submission received and AI analysis started',
    data: {
      id,
      status: 'analyzing',
      commit_sha: commitSha,
    },
  });
});

export const reviewSubmission = asyncHandler(async (req, res) => {
  const { id } = req.params;

  // Defense in depth: even if the route is already teacher-only, never allow
  // a non-teacher/admin caller to write a review from this controller.
  if (req.user.role !== 'teacher' && req.user.role !== 'admin') {
    throw new ApiError(403, 'Only teachers can review submissions');
  }

  const {
    final_score,
    teacher_feedback,
    // 'save'    -> persist edits, keep the evaluation as a draft (not yet visible to student)
    // 'approved'-> publish the teacher-final evaluation to the student
    // 'rejected'-> mark not approved; student sees only the rejection comment
    action = 'save',
    criteria_scores = [],
    strengths,
    areas_for_improvement,
    recommendations,
    suggested_next_steps,
  } = req.body;

  const normalizedAction =
    action === 'approved' || action === 'approve' ? 'approved' : action === 'rejected' || action === 'reject' ? 'rejected' : 'save';

  const [s] = await pool.query(
    `SELECT s.id, s.assessment_id, s.student_id, a.group_id
     FROM assessment_submissions s
     JOIN assessments a ON a.id = s.assessment_id
     WHERE s.id = ?`,
    [id]
  );
  if (!s.length) throw new ApiError(404, 'Submission not found');
  const submission = s[0];

  // A teacher may only review submissions belonging to a group they are
  // actually assigned to (proposal §4).
  if (req.user.role === 'teacher' && !(await teacherOwnsGroup(req.user.sub, submission.group_id))) {
    throw new ApiError(403, 'You are not assigned to this group');
  }

  const [evalRows] = await pool.query(
    `SELECT id, strengths, areas_for_improvement, recommendations, suggested_next_steps
     FROM ai_evaluations WHERE submission_id = ? ORDER BY id DESC LIMIT 1`,
    [id]
  );

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // ai_evaluations.status is a 3-value ENUM ('draft','approved','rejected') —
    // 'save' must map to 'draft', never be written to the column literally.
    const evalStatus = normalizedAction === 'save' ? 'draft' : normalizedAction;
    let aiEvaluationId;

    if (evalRows.length) {
      const existingEval = evalRows[0];
      aiEvaluationId = existingEval.id;
      await conn.query(
        `UPDATE ai_evaluations
         SET reviewed_by = ?,
             total_teacher_score = ?,
             status = ?,
             teacher_comment = ?,
             strengths = ?,
             areas_for_improvement = ?,
             recommendations = ?,
             suggested_next_steps = ?,
             reviewed_at = ?
         WHERE id = ?`,
        [
          req.user.sub,
          final_score ?? null,
          evalStatus,
          teacher_feedback || null,
          strengths ?? existingEval.strengths,
          areas_for_improvement ?? existingEval.areas_for_improvement,
          recommendations ?? existingEval.recommendations,
          suggested_next_steps ?? existingEval.suggested_next_steps,
          normalizedAction === 'save' ? null : new Date(),
          aiEvaluationId,
        ]
      );
    } else {
      // No AI evaluation exists yet for this submission (e.g. AI analysis
      // failed/errored). Rather than blocking the teacher, allow a manual
      // evaluation to be created — this becomes the one-and-only evaluation
      // record for the submission, same as the AI-generated path.
      const [inserted] = await conn.query(
        `INSERT INTO ai_evaluations
           (submission_id, reviewed_by, total_teacher_score, status, teacher_comment,
            strengths, areas_for_improvement, recommendations, suggested_next_steps, reviewed_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          req.user.sub,
          final_score ?? null,
          evalStatus,
          teacher_feedback || null,
          strengths || null,
          areas_for_improvement || null,
          recommendations || null,
          suggested_next_steps || null,
          normalizedAction === 'save' ? null : new Date(),
        ]
      );
      aiEvaluationId = inserted.insertId;
    }

    for (const cs of criteria_scores) {
      if (!cs.criterion_id) continue;
      await conn.query(
        `INSERT INTO criterion_scores (ai_evaluation_id, criterion_id, ai_recommended_score, ai_rationale, teacher_final_score)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           teacher_final_score = VALUES(teacher_final_score),
           ai_rationale = COALESCE(VALUES(ai_rationale), ai_rationale)`,
        [aiEvaluationId, cs.criterion_id, cs.ai_recommended_score ?? 0, cs.ai_rationale ?? null, cs.teacher_final_score ?? null]
      );
    }

    // Submission-level status must stay within its own ENUM — 'draft' is not
    // a valid assessment_submissions.status value, unlike ai_evaluations.status.
    const submissionStatus = normalizedAction === 'approved' ? 'approved' : normalizedAction === 'rejected' ? 'rejected' : 'teacher_reviewed';
    await conn.query(`UPDATE assessment_submissions SET status = ? WHERE id = ?`, [submissionStatus, id]);

    // The official gradebook and the feedback log are only written once the
    // evaluation is actually approved — a 'save' is just a persisted draft.
    if (normalizedAction === 'approved' && final_score !== undefined && submission.student_id) {
      await conn.query(
        `INSERT INTO assessment_scores (assessment_id, student_id, submission_id, score, feedback)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE submission_id = VALUES(submission_id), score = VALUES(score),
           feedback = VALUES(feedback), evaluated_at = NOW()`,
        [submission.assessment_id, submission.student_id, id, final_score, teacher_feedback || null]
      );
    }

    if (normalizedAction === 'approved' && teacher_feedback && submission.student_id) {
      await conn.query(
        `INSERT INTO teacher_feedback (student_id, teacher_id, assessment_id, content) VALUES (?, ?, ?, ?)`,
        [submission.student_id, req.user.sub, submission.assessment_id, teacher_feedback]
      );
    }

    await conn.commit();

    const [updated] = await pool.query(`SELECT * FROM assessment_submissions WHERE id = ?`, [id]);
    res.json({
      success: true,
      message: normalizedAction === 'save' ? 'Draft evaluation saved' : `Evaluation ${normalizedAction}`,
      data: updated[0],
    });
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
});

export const requestResubmission = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { teacher_feedback } = req.body;

  if (req.user.role !== 'teacher' && req.user.role !== 'admin') {
    throw new ApiError(403, 'Only teachers can request a resubmission');
  }

  const [rows] = await pool.query(
    `SELECT s.id, s.student_id, a.group_id
     FROM assessment_submissions s
     JOIN assessments a ON a.id = s.assessment_id
     WHERE s.id = ?`,
    [id]
  );
  if (!rows.length) throw new ApiError(404, 'Submission not found');

  const submission = rows[0];
  if (req.user.role === 'teacher' && !(await teacherOwnsGroup(req.user.sub, submission.group_id))) {
    throw new ApiError(403, 'You are not assigned to this group');
  }

  const [evalRows] = await pool.query(
    `SELECT id FROM ai_evaluations WHERE submission_id = ? ORDER BY id DESC LIMIT 1`,
    [id]
  );

  // Keep the existing schema untouched. The marker distinguishes an explicit
  // resubmission request from an ordinary rejection.
  const comment = teacher_feedback?.trim()
    ? `[RESUBMISSION_REQUESTED] ${teacher_feedback.trim()}`
    : '[RESUBMISSION_REQUESTED] Your teacher has requested that you resubmit this assignment.';

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    if (evalRows.length) {
      await conn.query(
        `UPDATE ai_evaluations
         SET status = 'rejected', teacher_comment = ?, reviewed_by = ?, reviewed_at = NOW()
         WHERE id = ?`,
        [comment, req.user.sub, evalRows[0].id]
      );
    } else {
      await conn.query(
        `INSERT INTO ai_evaluations
         (submission_id, reviewed_by, status, teacher_comment, reviewed_at)
         VALUES (?, ?, 'rejected', ?, NOW())`,
        [id, req.user.sub, comment]
      );
    }

    await conn.query(
      `UPDATE assessment_submissions SET status = 'rejected' WHERE id = ?`,
      [id]
    );

    await conn.commit();
    res.json({
      success: true,
      message: 'Resubmission requested',
      data: { id, status: 'rejected', resubmission_requested: true },
    });
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
});