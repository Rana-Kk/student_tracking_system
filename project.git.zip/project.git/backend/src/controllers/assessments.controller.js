import { pool } from '../config/db.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { teacherOwnsGroup } from '../utils/scope.js';

function normalizeDate(dateStr) {
  if (!dateStr || typeof dateStr !== 'string') return null;
  const trimmed = dateStr.trim();
  if (!trimmed) return null;

  const ymdMatch = trimmed.match(/^(\d{4})[-/.](0?[1-9]|[12]\d|3[01])[-/.](0?[1-9]|[12]\d|3[01])/);
  if (ymdMatch) {
    const year = ymdMatch[1];
    const p1 = parseInt(ymdMatch[2], 10);
    const p2 = parseInt(ymdMatch[3], 10);
    let month, day;
    if (p1 > 12 && p2 <= 12) {
      day = String(p1).padStart(2, '0');
      month = String(p2).padStart(2, '0');
    } else {
      month = String(p1).padStart(2, '0');
      day = String(p2).padStart(2, '0');
    }
    return `${year}-${month}-${day}`;
  }

  const dmyMatch = trimmed.match(/^(0?[1-9]|[12]\d|3[01])[-/.](0?[1-9]|1[0-2])[-/.](\d{4})/);
  if (dmyMatch) {
    const day = dmyMatch[1].padStart(2, '0');
    const month = dmyMatch[2].padStart(2, '0');
    const year = dmyMatch[3];
    return `${year}-${month}-${day}`;
  }

  const d = new Date(trimmed);
  if (!isNaN(d.getTime())) {
    return d.toISOString().split('T')[0];
  }
  return null;
}

// GET /api/assessments (optional ?group_id=...)
export const getAllAssessments = asyncHandler(async (req, res) => {
  const { group_id } = req.query;
  let query = `
    SELECT a.*, sg.name AS group_name, c.name AS course_name
    FROM assessments a
    LEFT JOIN student_groups sg ON a.group_id = sg.id
    LEFT JOIN courses c ON sg.course_id = c.id
    WHERE 1=1
  `;
  const params = [];

  if (req.user.role === 'teacher') {
    query += `
      AND EXISTS (
        SELECT 1 FROM group_teachers gt
        WHERE gt.group_id = a.group_id AND gt.teacher_id = ?
      )
    `;
    params.push(req.user.sub);
  }

  if (req.user.role === 'student') {
    query += `
      AND EXISTS (
        SELECT 1 FROM group_students gs
        WHERE gs.group_id = a.group_id AND gs.student_id = ?
      )
    `;
    params.push(req.user.sub);
  }

  if (group_id) {
    query += ' AND a.group_id = ?';
    params.push(group_id);
  }

  query += ' ORDER BY a.id DESC';

  const [assessments] = await pool.query(query, params);
  res.status(200).json({ success: true, count: assessments.length, data: assessments });
});
// GET /api/assessments/student
// Student'ın kendi gruplarındaki assessment'ları
// ve varsa kendi submission durumlarını getirir.
export const getStudentAssessments = asyncHandler(async (req, res) => {
  const studentId = req.user.sub

  if (req.user.role !== 'student') {
    throw new ApiError(
      403,
      'Only students can access student assessments'
    )
  }

  const [rows] = await pool.query(
    `
    SELECT
      a.id,
      a.group_id,
      a.title,
      a.description,
      a.type,
      a.submission_mode,
      a.repo_slug,
      a.due_date,
      a.assessment_date,
      a.max_score,

      sg.name AS group_name,
      c.name AS course_name,

      s.id AS submission_id,
      s.status AS submission_status,
      s.github_url,
      s.submitted_at,
      s.ai_score,
      s.ai_feedback,
      submitter.name AS submitted_by_name,
      latest_eval.teacher_comment AS resubmission_comment

    FROM assessments a

    INNER JOIN student_groups sg
      ON sg.id = a.group_id

    INNER JOIN courses c
      ON c.id = sg.course_id

    INNER JOIN group_students gs
      ON gs.group_id = a.group_id
      AND gs.student_id = ?

    LEFT JOIN assessment_submissions s
      ON s.assessment_id = a.id
      AND s.student_id = ?

    -- Team assignments: submitted_by is stamped on every teammate's own
    -- submission row with whichever student actually clicked "Submit", so
    -- a teammate who didn't upload anything themselves can still see who
    -- on the team did (and, via github_url above, what was uploaded).
    LEFT JOIN users submitter
      ON submitter.id = s.submitted_by

    LEFT JOIN ai_evaluations latest_eval
      ON latest_eval.id = (
        SELECT ae.id FROM ai_evaluations ae
        WHERE ae.submission_id = s.id
        ORDER BY ae.id DESC
        LIMIT 1
      )
      AND s.status = 'rejected'

    ORDER BY a.due_date ASC, a.id DESC
    `,
    [studentId, studentId]
  )

  res.json({
    success: true,
    count: rows.length,
    data: rows,
  })
})
export const getAssessments = getAllAssessments;

// GET /api/assessments/:id
export const getAssessmentById = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const [assessment] = await pool.query(
    `SELECT a.*, sg.name AS group_name, c.name AS course_name 
     FROM assessments a
     LEFT JOIN student_groups sg ON a.group_id = sg.id
     LEFT JOIN courses c ON sg.course_id = c.id
     WHERE a.id = ?
       AND (
         ? <> 'teacher'
         OR EXISTS (SELECT 1 FROM group_teachers gt WHERE gt.group_id = a.group_id AND gt.teacher_id = ?)
       )`,
    [id, req.user.role, req.user.sub]
  );

  if (assessment.length === 0) {
    throw new ApiError(404, 'Assessment not found');
  }

  const [criteria] = await pool.query(
    'SELECT * FROM assessment_criteria WHERE assessment_id = ? ORDER BY sort_order ASC, id ASC',
    [id]
  );

  res.status(200).json({
    success: true,
    data: {
      ...assessment[0],
      criteria
    }
  });
});

// POST /api/assessments
export const createAssessment = asyncHandler(async (req, res) => {
  const {
    group_id,
    title,
    description,
    type = 'assignment',
    submission_mode = 'individual',
    repo_slug,
    due_date,
    assessment_date,
    max_score = 100,
    criteria = []
  } = req.body;

  const created_by = req.user.sub;

  if (!group_id || !title) {
    throw new ApiError(400, 'Group ID and assessment title are required');
  }

const [groupExists] = await pool.query(
  'SELECT id FROM student_groups WHERE id = ?',
  [group_id]
)

if (groupExists.length === 0) {
  throw new ApiError(404, 'Student group not found');
}

if (req.user.role === 'teacher') {
  const isOwned = await teacherOwnsGroup(req.user.sub, group_id)
  if (!isOwned) {
    throw new ApiError(403, 'You are not assigned to this group')
  }
}

  const cleanDueDate = normalizeDate(due_date);
  const cleanAssessmentDate = normalizeDate(assessment_date);

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const [result] = await connection.query(
      `INSERT INTO assessments 
       (group_id, title, description, type, submission_mode, repo_slug, due_date, assessment_date, max_score, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        group_id,
        title.trim(),
        description?.trim() || null,
        type,
        submission_mode,
        repo_slug?.trim() || null,
        cleanDueDate,
        cleanAssessmentDate,
        max_score,
        created_by
      ]
    );

    const assessmentId = result.insertId;

    if (Array.isArray(criteria) && criteria.length > 0) {
      for (let i = 0; i < criteria.length; i++) {
        const item = criteria[i];
        if (item.name) {
          await connection.query(
            `INSERT INTO assessment_criteria (assessment_id, name, description, max_score, sort_order)
             VALUES (?, ?, ?, ?, ?)`,
            [assessmentId, item.name.trim(), item.description?.trim() || null, item.max_score || 0, item.sort_order || i + 1]
          );
        }
      }
    }

    await connection.commit();

    const [newAssessment] = await pool.query('SELECT * FROM assessments WHERE id = ?', [assessmentId]);
    const [savedCriteria] = await pool.query('SELECT * FROM assessment_criteria WHERE assessment_id = ? ORDER BY sort_order ASC', [assessmentId]);

    res.status(201).json({
      success: true,
      message: 'Assessment created successfully',
      data: {
        ...newAssessment[0],
        criteria: savedCriteria
      }
    });
  } catch (err) {
    await connection.rollback();
    throw err;
  } finally {
    connection.release();
  }
});

// PUT /api/assessments/:id
export const updateAssessment = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const {
    group_id,
    title,
    description,
    type,
    submission_mode,
    repo_slug,
    due_date,
    assessment_date,
    max_score,
    criteria
  } = req.body;

  const [existing] = await pool.query(
    `SELECT a.id, a.group_id
     FROM assessments a
     WHERE a.id = ?
       AND (
         ? <> 'teacher'
         OR EXISTS (SELECT 1 FROM group_teachers gt WHERE gt.group_id = a.group_id AND gt.teacher_id = ?)
       )`,
    [id, req.user.role, req.user.sub]
  );
  if (existing.length === 0) {
    throw new ApiError(404, 'Assessment not found');
  }

  if (req.user.role === 'teacher' && group_id !== undefined) {
    const [ownedGroup] = await pool.query(
      `SELECT 1 FROM group_teachers WHERE teacher_id = ? AND group_id = ? LIMIT 1`,
      [req.user.sub, group_id]
    );
    if (!ownedGroup.length) throw new ApiError(403, 'You are not assigned to this group');
  }

  const cleanDueDate = due_date !== undefined ? normalizeDate(due_date) : undefined;
  const cleanAssessmentDate = assessment_date !== undefined ? normalizeDate(assessment_date) : undefined;

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    await connection.query(
      `UPDATE assessments SET 
       group_id = COALESCE(?, group_id),
       title = COALESCE(?, title),
       description = COALESCE(?, description),
       type = COALESCE(?, type),
       submission_mode = COALESCE(?, submission_mode),
       repo_slug = COALESCE(?, repo_slug),
       due_date = COALESCE(?, due_date),
       assessment_date = COALESCE(?, assessment_date),
       max_score = COALESCE(?, max_score)
       WHERE id = ?`,
      [
        group_id,
        title ? title.trim() : null,
        description !== undefined ? description.trim() : null,
        type,
        submission_mode,
        repo_slug !== undefined ? (repo_slug?.trim() || null) : null,
        cleanDueDate === undefined ? null : cleanDueDate,
        cleanAssessmentDate === undefined ? null : cleanAssessmentDate,
        max_score,
        id
      ]
    );

    // Kriter listesi gönderildiyse güncelle
    if (Array.isArray(criteria)) {
      await connection.query('DELETE FROM assessment_criteria WHERE assessment_id = ?', [id]);
      for (let i = 0; i < criteria.length; i++) {
        const item = criteria[i];
        if (item.name) {
          await connection.query(
            `INSERT INTO assessment_criteria (assessment_id, name, description, max_score, sort_order)
             VALUES (?, ?, ?, ?, ?)`,
            [id, item.name.trim(), item.description?.trim() || null, item.max_score || 0, item.sort_order || i + 1]
          );
        }
      }
    }

    await connection.commit();

    const [updated] = await pool.query('SELECT * FROM assessments WHERE id = ?', [id]);
    const [updatedCriteria] = await pool.query('SELECT * FROM assessment_criteria WHERE assessment_id = ? ORDER BY sort_order ASC', [id]);

    res.status(200).json({
      success: true,
      message: 'Assessment updated successfully',
      data: {
        ...updated[0],
        criteria: updatedCriteria
      }
    });
  } catch (err) {
    await connection.rollback();
    throw err;
  } finally {
    connection.release();
  }
});

// DELETE /api/assessments/:id
export const deleteAssessment = asyncHandler(async (req, res) => {
  const { id } = req.params;

  const [existing] = await pool.query('SELECT id, group_id FROM assessments WHERE id = ?', [id]);
  if (existing.length === 0) {
    throw new ApiError(404, 'Assessment not found');
  }

  // A teacher may only delete assessments that belong to a group they are
  // actually assigned to (createAssessment/updateAssessment already enforce
  // this — delete was missing the same check).
  if (req.user.role === 'teacher' && !(await teacherOwnsGroup(req.user.sub, existing[0].group_id))) {
    throw new ApiError(403, 'You are not assigned to this group');
  }

  await pool.query('DELETE FROM assessments WHERE id = ?', [id]);
  res.status(200).json({ success: true, message: 'Assessment deleted successfully' });
});