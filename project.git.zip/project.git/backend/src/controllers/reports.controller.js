import { pool } from '../config/db.js';
import { ApiError } from '../utils/ApiError.js';
import { asyncHandler } from '../utils/asyncHandler.js';
import { teacherHasStudent } from '../utils/scope.js';

export const studentReport = asyncHandler(async (req, res) => {
  const sid = req.user.role === 'student' ? req.user.sub : req.params.studentId;

  if (req.user.role === 'teacher' && !(await teacherHasStudent(req.user.sub, sid))) {
    throw new ApiError(403, 'You do not have access to this student');
  }

  const [u] = await pool.query(`SELECT id,name,email FROM users WHERE id=? AND role='student'`, [sid]);
  if (!u.length) throw new ApiError(404, 'Student not found');

  const [attendance] = await pool.query(`SELECT * FROM attendance WHERE student_id=? ORDER BY attendance_date DESC`, [sid]);
  const [scores] = await pool.query(
    `SELECT s.*, a.title assessment_title, a.max_score FROM assessment_scores s
     JOIN assessments a ON a.id=s.assessment_id WHERE s.student_id=? ORDER BY a.id DESC`,
    [sid]
  );
  const [quizzes] = await pool.query(
    `SELECT qr.*, q.title quiz_title, q.topic, q.max_score, q.quiz_date FROM quiz_results qr
     JOIN quizzes q ON q.id=qr.quiz_id WHERE qr.student_id=? ORDER BY qr.completed_at DESC`,
    [sid]
  );
  const [competencies] = await pool.query(
    `SELECT c.name, sc.score FROM student_competencies sc
     JOIN competencies c ON c.id=sc.competency_id WHERE sc.student_id=? ORDER BY c.name`,
    [sid]
  );
  const [feedback] = await pool.query(
    `SELECT tf.*, a.title assessment_title, t.name teacher_name FROM teacher_feedback tf
     JOIN users t ON t.id=tf.teacher_id LEFT JOIN assessments a ON a.id=tf.assessment_id
     WHERE tf.student_id=? ORDER BY tf.created_at DESC`,
    [sid]
  );
  const [certificates] = await pool.query(`SELECT * FROM certificates WHERE student_id=? ORDER BY issue_date DESC`, [sid]);

  res.json({
    success: true,
    data: { student: u[0], attendance, scores, quizzes, competencies, feedback, certificates },
  });
});
