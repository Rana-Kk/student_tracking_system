import { useEffect, useMemo, useState } from 'react'
import { apiFetch, ApiError } from '../../lib/api'
import type { TeacherPage } from '../../layouts/TeacherLayout'

interface Group {
  id: number
  name: string
  course_name?: string
}

interface Assessment {
  id: number
  group_id: number
  group_name?: string
  title: string
  submission_mode: 'individual' | 'team' | string
  due_date: string | null
  max_score: number
}

interface Submission {
  id: number
  assessment_id: number
  student_id?: number
  student_name?: string
  team_name?: string
  github_repo_url?: string
  submitted_by_name?: string
  submitted_at: string | null
  status: string
  ai_score?: number | null
  final_score?: number | null
}

const STATUS_CFG: Record<string, { bg: string; color: string; label: string }> = {
  'Not Submitted':  { bg: '#F1F5F9', color: '#64748B', label: 'Not Submitted' },
  'Submitted':      { bg: '#DBEAFE', color: '#1E40AF', label: 'Submitted' },
  'submitted':      { bg: '#DBEAFE', color: '#1E40AF', label: 'Submitted' },
  'Analyzing':      { bg: '#EDE9FE', color: '#6D28D9', label: 'Analyzing…' },
  'analyzing':      { bg: '#EDE9FE', color: '#6D28D9', label: 'Analyzing…' },
  'AI Draft Ready': { bg: '#FEF3C7', color: '#B45309', label: 'Review Required' },
  'ai_reviewed':    { bg: '#FEF3C7', color: '#B45309', label: 'Review Required' },
  'Teacher Review': { bg: '#FEF3C7', color: '#92400E', label: 'Review Required' },
  'Approved':       { bg: '#DCFCE7', color: '#15803D', label: 'Approved' },
  'approved':       { bg: '#DCFCE7', color: '#15803D', label: 'Approved' },
  'Rejected':       { bg: '#FEE2E2', color: '#B91C1C', label: 'Rejected' },
  'rejected':       { bg: '#FEE2E2', color: '#B91C1C', label: 'Rejected' },
  'error':          { bg: '#FEE2E2', color: '#B91C1C', label: 'AI Analysis Failed' },
}

function StatusPill({ status }: { status: string }) {
  const cfg = STATUS_CFG[status] || { bg: '#F1F5F9', color: '#64748B', label: status }
  return (
    <span className="text-xs font-medium px-2.5 py-1 rounded-full" style={{ background: cfg.bg, color: cfg.color }}>
      {cfg.label}
    </span>
  )
}

interface Props {
  onNavigate: (page: TeacherPage, submissionId?: number) => void
}

export default function TeacherSubmissions({ onNavigate }: Props) {
  const [groups, setGroups] = useState<Group[]>([])
  const [assessments, setAssessments] = useState<Assessment[]>([])
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [selectedGroupId, setSelectedGroupId] = useState<number | null>(null)
  const [selectedAssessmentId, setSelectedAssessmentId] = useState<number | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const loadData = async () => {
      setLoading(true)
      setError('')
      try {
        // /groups ve /assessments backend'de zaten öğretmene göre filtreli.
        const [grpRes, assRes, subRes] = await Promise.all([
          apiFetch('/groups'),
          apiFetch('/assessments'),
          apiFetch('/submissions'),
        ])

        const myGroups: Group[] = grpRes.data || []
        const myAssessments: Assessment[] = assRes.data || []
        const myAssessmentIds = new Set(myAssessments.map((a) => a.id))
        // /submissions henüz teacher-scoped olmayabilir; client-side güvenlik filtresi.
        const mySubmissions: Submission[] = (subRes.data || []).filter((s: Submission) => myAssessmentIds.has(s.assessment_id))

        setGroups(myGroups)
        setAssessments(myAssessments)
        setSubmissions(mySubmissions)

        if (myGroups.length > 0) {
          setSelectedGroupId(myGroups[0].id)
          const firstGroupAssessments = myAssessments.filter((a) => a.group_id === myGroups[0].id)
          if (firstGroupAssessments.length > 0) setSelectedAssessmentId(firstGroupAssessments[0].id)
        }
      } catch (err) {
        setError(err instanceof ApiError ? err.message : 'Failed to load submissions')
      } finally {
        setLoading(false)
      }
    }
    loadData()
  }, [])

  const groupAssessments = useMemo(
    () => assessments.filter((a) => a.group_id === selectedGroupId),
    [assessments, selectedGroupId]
  )

  const selectedAssessment = groupAssessments.find((a) => a.id === selectedAssessmentId) || groupAssessments[0]
  const filteredSubmissions = submissions.filter((s) => s.assessment_id === selectedAssessment?.id)

  function handleSelectGroup(groupId: number) {
    setSelectedGroupId(groupId)
    const firstAssessment = assessments.find((a) => a.group_id === groupId)
    setSelectedAssessmentId(firstAssessment?.id ?? null)
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold" style={{ fontFamily: 'Outfit, sans-serif' }}>Submissions</h1>
        <p className="text-sm mt-0.5" style={{ color: 'var(--muted-foreground)' }}>Review student submissions for your assigned groups.</p>
      </div>

      {error && (
        <div className="p-4 rounded-xl text-sm mb-4" style={{ background: '#FEE2E2', color: '#B91C1C' }}>{error}</div>
      )}

      {loading ? (
        <p className="text-sm text-gray-500">Loading...</p>
      ) : groups.length === 0 ? (
        <div className="rounded-xl py-12 text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <p className="text-sm text-gray-500">No groups assigned to you yet.</p>
        </div>
      ) : (
        <>
          {/* Group selector */}
          <div className="flex gap-2 mb-3 flex-wrap">
            {groups.map((g) => (
              <button
                key={g.id}
                onClick={() => handleSelectGroup(g.id)}
                className="px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                style={{
                  background: selectedGroupId === g.id ? 'var(--foreground)' : 'var(--card)',
                  color: selectedGroupId === g.id ? 'var(--background)' : 'var(--foreground)',
                  border: `1px solid ${selectedGroupId === g.id ? 'var(--foreground)' : 'var(--border)'}`,
                  cursor: 'pointer',
                }}
              >
                {g.name}
                {g.course_name && <span className="ml-2 text-xs opacity-70">{g.course_name}</span>}
              </button>
            ))}
          </div>

          {groupAssessments.length === 0 ? (
            <div className="rounded-xl py-12 text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
              <p className="text-sm text-gray-500">No assessments found for this group.</p>
            </div>
          ) : (
            <>
              {/* Assessment selector buttons */}
              <div className="flex gap-2 mb-5 flex-wrap">
                {groupAssessments.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => setSelectedAssessmentId(a.id)}
                    className="px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                    style={{
                      background: selectedAssessment?.id === a.id ? 'var(--primary)' : 'var(--card)',
                      color: selectedAssessment?.id === a.id ? 'white' : 'var(--foreground)',
                      border: `1px solid ${selectedAssessment?.id === a.id ? 'var(--primary)' : 'var(--border)'}`,
                      cursor: 'pointer',
                    }}
                  >
                    {a.title}
                  </button>
                ))}
              </div>

              {/* Submissions table — Overview ile aynı stil */}
              <div className="rounded-xl overflow-hidden" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                <div className="px-5 py-3 border-b" style={{ borderColor: 'var(--border)', background: 'var(--muted)' }}>
                  <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>Student Overview</p>
                </div>
                <table className="w-full">
                  <thead>
                    <tr style={{ borderBottom: '1px solid var(--border)', background: 'var(--muted)' }}>
                      {['Student', 'Repository', 'Status', 'Grade'].map((h) => (
                        <th key={h} className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredSubmissions.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="px-4 py-8 text-center text-sm" style={{ color: 'var(--muted-foreground)' }}>
                          No submissions found.
                        </td>
                      </tr>
                    ) : (
                      filteredSubmissions.map((sub, i) => (
                        <tr
                          key={sub.id}
                          onClick={() => onNavigate('aievaluations', sub.id)}
                          className="cursor-pointer hover:bg-gray-50 transition-colors"
                          style={{ borderBottom: i < filteredSubmissions.length - 1 ? '1px solid var(--border)' : 'none' }}
                        >
                          <td className="px-4 py-4 text-sm font-semibold text-indigo-600">
                            {sub.team_name ?? sub.student_name ?? `Student #${sub.student_id}`}
                          </td>
                          <td className="px-4 py-4" onClick={(e) => e.stopPropagation()}>
                            {sub.github_repo_url ? (
                              <a href={sub.github_repo_url} target="_blank" rel="noreferrer" className="text-xs mono text-indigo-600 hover:underline">
                                ⎇ {sub.github_repo_url}
                              </a>
                            ) : <span className="text-xs text-gray-400">—</span>}
                            {/* Team assignment: this row's own student may not be
                                who actually uploaded — show the real uploader. */}
                            {selectedAssessment?.submission_mode === 'team' && sub.submitted_by_name && sub.submitted_by_name !== sub.student_name && (
                              <div className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>
                                Uploaded by {sub.submitted_by_name}
                              </div>
                            )}
                          </td>
                          <td className="px-4 py-4">
                            <StatusPill status={sub.status} />
                          </td>
                          <td className="px-4 py-4 text-sm font-bold mono">
                            {sub.final_score ?? sub.ai_score ?? '-'} / {selectedAssessment?.max_score || 100}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </>
      )}
    </div>
  )
}