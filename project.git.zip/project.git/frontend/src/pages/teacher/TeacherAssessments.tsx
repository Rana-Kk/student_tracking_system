import { useEffect, useState, useMemo } from 'react'
import { apiFetch, ApiError } from '../../lib/api'
import type { SubmissionMode, SubmissionStatus } from '../../types'
import type { TeacherPage } from '../../layouts/TeacherLayout'

/* ────────────────────────────────────────────────────────────────────
   Types
───────────────────────────────────────────────────────────────────── */

interface Criterion {
  id?: number | string
  assessment_id?: number
  name: string
  description: string | null
  max_score: number
  sort_order?: number
}

interface Assessment {
  id: number
  group_id: number
  group_name?: string
  course_name?: string
  title: string
  description: string | null
  type: string
  submission_mode: SubmissionMode
  repo_slug: string | null
  due_date: string | null
  assessment_date: string | null
  max_score: number
  criteria?: Criterion[]
}

interface Group {
  id: number
  name: string
  course_id: number
  course_name?: string
  studentCount?: number
}

interface Submission {
  id: number
  assessment_id: number
  student_id?: number
  student_name?: string
  team_id?: number
  team_name?: string
  github_repo_url?: string
  submitted_at: string | null
  status: SubmissionStatus
  ai_score?: number
  ai_feedback?: string
  final_score?: number
  criteria_scores?: any[]
}

interface Props {
  onNavigate: (page: TeacherPage, id?: number) => void
}

/* ────────────────────────────────────────────────────────────────────
   Shared helpers & Colors
───────────────────────────────────────────────────────────────────── */

const TYPE_COLORS: Record<string, { bg: string; color: string }> = {
  Project:        { bg: '#DBEAFE', color: '#1E40AF' },
  Assignment:     { bg: '#F3E8FF', color: '#6D28D9' },
  Presentation:   { bg: '#CFFAFE', color: '#0E7490' },
  Practical:      { bg: '#FEF3C7', color: '#92400E' },
  'Final Project':{ bg: '#FCE7F3', color: '#9D174D' },
  Other:          { bg: '#F1F5F9', color: '#475569' },
}

const STATUS_CFG: Record<string, { bg: string; color: string; label: string }> = {
  'Not Submitted': { bg: '#F1F5F9', color: '#64748B', label: 'Not Submitted' },
  'Submitted':     { bg: '#DBEAFE', color: '#1E40AF', label: 'Submitted' },
  'pending':       { bg: '#DBEAFE', color: '#1E40AF', label: 'Submitted' },
  'Analyzing':     { bg: '#EDE9FE', color: '#6D28D9', label: 'Analyzing' },
  'analyzing':     { bg: '#EDE9FE', color: '#6D28D9', label: 'Analyzing' },
  'AI Draft Ready':{ bg: '#FEF3C7', color: '#B45309', label: 'AI Draft Ready' },
  'ai_reviewed':   { bg: '#FEF3C7', color: '#B45309', label: 'AI Reviewed' },
  'Teacher Review':{ bg: '#FEF3C7', color: '#92400E', label: 'Review Required' },
  'Approved':      { bg: '#DCFCE7', color: '#15803D', label: 'Approved' },
  'approved':      { bg: '#DCFCE7', color: '#15803D', label: 'Approved' },
  'Rejected':      { bg: '#FEE2E2', color: '#B91C1C', label: 'Rejected' },
}

function StatusPill({ status }: { status: string }) {
  const c = STATUS_CFG[status] || { bg: '#F1F5F9', color: '#64748B', label: status }
  return (
    <span className="text-xs font-medium px-2 py-0.5 rounded-full" style={{ background: c.bg, color: c.color }}>
      {c.label}
    </span>
  )
}

function ModeTag({ mode }: { mode: SubmissionMode | string }) {
  const isTeam = mode?.toLowerCase() === 'team'
  return (
    <span className="text-xs font-medium px-2 py-0.5 rounded-full" style={{ background: isTeam ? '#EDE9FE' : '#DBEAFE', color: isTeam ? '#6D28D9' : '#1E40AF' }}>
      {isTeam ? 'Team' : 'Individual'}
    </span>
  )
}

function computeAssessmentStats(a: Assessment, allSubs: Submission[]) {
  const subs = allSubs.filter(s => s.assessment_id === a.id)
  const submitted = subs.filter(s => s.status !== 'Not Submitted').length
  const approved = subs.filter(s => String(s.status) === 'approved' || String(s.status) === 'Approved').length
  const needsReview = subs.filter(s => String(s.status) === 'ai_reviewed' || String(s.status) === 'AI Draft Ready' || String(s.status) === 'Teacher Review').length
  const analyzing = subs.filter(s => String(s.status) === 'analyzing' || String(s.status) === 'Analyzing').length
  const total = Math.max(subs.length, 1)
  return { submitted, approved, needsReview, analyzing, total }
}

/* ────────────────────────────────────────────────────────────────────
   Assessment Card Component
───────────────────────────────────────────────────────────────────── */

function AssessmentCard({ a, subs, onClick }: { a: Assessment; subs: Submission[]; onClick: () => void }) {
  const tc = TYPE_COLORS[a.type] ?? TYPE_COLORS.Assignment
  const { submitted, approved, needsReview, analyzing, total } = computeAssessmentStats(a, subs)
  const pct = total > 0 ? Math.round((submitted / total) * 100) : 0
  const overdue = a.due_date ? new Date(a.due_date) < new Date() && submitted < total : false

  return (
    <button
      onClick={onClick}
      className="w-full text-left rounded-xl p-4 transition-shadow hover:shadow-md"
      style={{ background: 'var(--card)', border: '1px solid var(--border)', cursor: 'pointer' }}
    >
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs font-medium px-2 py-0.5 rounded-full" style={{ background: tc.bg, color: tc.color }}>{a.type}</span>
          <ModeTag mode={a.submission_mode} />
          {overdue && <span className="text-xs font-medium px-2 py-0.5 rounded-full" style={{ background: '#FEE2E2', color: '#B91C1C' }}>Overdue</span>}
        </div>
        <span className="text-xs mono flex-shrink-0" style={{ color: 'var(--muted-foreground)' }}>
          Due {a.due_date ? a.due_date.split('T')[0] : '—'}
        </span>
      </div>

      <p className="text-sm font-semibold mb-3 leading-snug" style={{ fontFamily: 'Outfit, sans-serif' }}>{a.title}</p>

      <div className="mb-3">
        <div className="flex justify-between text-xs mb-1" style={{ color: 'var(--muted-foreground)' }}>
          <span>Submissions</span>
          <span className="mono">{submitted}/{total}</span>
        </div>
        <div className="rounded-full overflow-hidden" style={{ height: '5px', background: 'var(--secondary)' }}>
          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: pct === 100 ? '#15803D' : 'var(--primary)' }} />
        </div>
      </div>

      <div className="flex items-center gap-3 flex-wrap">
        {approved > 0 && (
          <span className="flex items-center gap-1 text-xs" style={{ color: '#15803D' }}>
            <span>✓</span><span className="mono">{approved} approved</span>
          </span>
        )}
        {needsReview > 0 && (
          <span className="flex items-center gap-1 text-xs font-semibold" style={{ color: '#B45309' }}>
            <span>⚑</span><span className="mono">{needsReview} review</span>
          </span>
        )}
        {analyzing > 0 && (
          <span className="flex items-center gap-1 text-xs" style={{ color: '#6D28D9' }}>
            <span>✦</span><span className="mono">{analyzing} analyzing</span>
          </span>
        )}
        {submitted === 0 && (
          <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>No submissions yet</span>
        )}
        <span className="ml-auto text-xs" style={{ color: 'var(--muted-foreground)' }}>{a.max_score} pts</span>
      </div>
    </button>
  )
}

/* ────────────────────────────────────────────────────────────────────
   Assessment Detail View (5 Tabs)
───────────────────────────────────────────────────────────────────── */

type DetailTab = 'overview' | 'rubric' | 'submissions' | 'evaluations' | 'results'

function AssessmentDetail({ a, groups, allSubs, onBack, onDeleted, onEdit, onNavigate }: { a: Assessment; groups: Group[]; allSubs: Submission[]; onBack: () => void; onDeleted: () => void; onEdit: (a: Assessment) => void; onNavigate: (page: TeacherPage, id?: number) => void }) {
  const [tab, setTab] = useState<DetailTab>('overview')
  const [detailAssessment, setDetailAssessment] = useState<Assessment>(a)
  const [loadingDetail, setLoadingDetail] = useState(false)

  const group = groups.find(g => g.id === a.group_id)
  const subs = allSubs.filter(s => s.assessment_id === a.id)
  const { submitted, approved, needsReview, total } = computeAssessmentStats(a, allSubs)
  const tc = TYPE_COLORS[a.type] ?? TYPE_COLORS.Assignment

  useEffect(() => {
    const fetchDetail = async () => {
      setLoadingDetail(true)
      try {
        const res = await apiFetch(`/assessments/${a.id}`)
        if (res.data) setDetailAssessment(res.data)
      } catch (err) {
        // Fallback to prop
      } finally {
        setLoadingDetail(false)
      }
    }
    fetchDetail()
  }, [a.id])

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this assignment?')) return
    try {
      await apiFetch(`/assessments/${a.id}`, { method: 'DELETE' })
      onDeleted()
    } catch (err: any) {
      alert(err.message || 'Failed to delete assessment')
    }
  }

  const TABS: { id: DetailTab; label: string }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'rubric', label: `Evaluation Criteria (${detailAssessment.criteria?.length || 0})` },
    { id: 'submissions', label: `Submissions (${subs.length})` },
    { id: 'evaluations', label: `AI Evaluations (${subs.filter(s => s.ai_score !== null && s.ai_score !== undefined).length})` },
    { id: 'results', label: 'Results' },
  ]

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Breadcrumb */}
      <div className="flex items-center justify-between text-sm mb-4">
        <div className="flex items-center gap-2" style={{ color: 'var(--muted-foreground)' }}>
          <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--primary)', padding: 0, fontSize: '14px' }}>
            ← Assessments
          </button>
          <span>/</span>
          <span className="font-medium" style={{ color: 'var(--foreground)' }}>{group?.name || `Group #${a.group_id}`}</span>
          <span>/</span>
          <span className="font-medium truncate max-w-xs" style={{ color: 'var(--foreground)' }}>{a.title}</span>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => onEdit(detailAssessment)}
            className="text-xs px-3 py-1.5 rounded-lg font-medium"
            style={{ border: '1px solid var(--border)', color: 'var(--foreground)', background: 'transparent', cursor: 'pointer' }}
          >
            Edit Assignment
          </button>
          <button
            onClick={handleDelete}
            className="text-xs px-3 py-1.5 rounded-lg font-medium"
            style={{ border: '1px solid #FCA5A5', color: '#B91C1C', background: 'transparent', cursor: 'pointer' }}
          >
            Delete Assignment
          </button>
        </div>
      </div>

      {/* Header card */}
      <div className="rounded-xl p-5 mb-5" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="text-xs font-semibold px-2.5 py-1 rounded-md" style={{ background: '#EFF6FF', color: '#1E40AF', border: '1px solid #BFDBFE' }}>
                📌 {group?.name || `Group #${a.group_id}`}
              </span>
              <span className="text-xs font-medium px-2 py-0.5 rounded-full" style={{ background: tc.bg, color: tc.color }}>{a.type}</span>
              <ModeTag mode={a.submission_mode} />
              {a.repo_slug && (
                <span className="text-xs mono px-2 py-0.5 rounded bg-gray-100 text-gray-700">
                  Repo: {a.repo_slug}
                </span>
              )}
            </div>
            <h1 className="text-xl font-semibold mb-1" style={{ fontFamily: 'Outfit, sans-serif' }}>{a.title}</h1>
          </div>
          <div className="flex gap-4 flex-shrink-0">
            {[
              { label: 'Assessment Date', value: a.assessment_date ? a.assessment_date.split('T')[0] : '—' },
              { label: 'Due Date', value: a.due_date ? a.due_date.split('T')[0] : '—' },
              { label: 'Max Score', value: `${a.max_score} pts` },
            ].map(({ label, value }) => (
              <div key={label} className="text-right">
                <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{label}</p>
                <p className="text-sm font-semibold mono">{value}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Stats strip */}
        <div className="mt-4 pt-4 flex gap-6 flex-wrap" style={{ borderTop: '1px solid var(--border)' }}>
          {[
            { label: 'Submissions Total', value: subs.length, color: 'var(--foreground)' },
            { label: 'Submitted', value: submitted, color: '#1D4ED8' },
            { label: 'Approved', value: approved, color: '#15803D' },
            { label: 'Needs Review', value: needsReview, color: '#B45309' },
          ].map(({ label, value, color }) => (
            <div key={label}>
              <p className="text-2xl font-bold mono" style={{ color }}>{value}</p>
              <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{label}</p>
            </div>
          ))}
          <div className="flex-1 flex items-end pb-1 min-w-32">
            <div className="w-full">
              <div className="flex justify-between text-xs mb-1" style={{ color: 'var(--muted-foreground)' }}>
                <span>Submission progress</span>
                <span className="mono">{total > 0 ? Math.round((submitted / total) * 100) : 0}%</span>
              </div>
              <div className="rounded-full overflow-hidden" style={{ height: '6px', background: 'var(--secondary)' }}>
                <div className="h-full rounded-full" style={{ width: `${total > 0 ? (submitted / total) * 100 : 0}%`, background: 'var(--primary)' }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-5 border-b" style={{ borderColor: 'var(--border)' }}>
        {TABS.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className="px-4 py-2.5 text-sm font-medium whitespace-nowrap"
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              color: tab === t.id ? 'var(--primary)' : 'var(--muted-foreground)',
              borderBottom: tab === t.id ? '2px solid var(--primary)' : '2px solid transparent',
              marginBottom: '-1px',
            }}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab Panels */}
      {tab === 'overview' && (
        <div className="space-y-5">
          {detailAssessment.description && (
             <div className="rounded-xl p-4" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
               <h3 className="text-sm font-semibold mb-2">Description</h3>
               <p className="text-sm whitespace-pre-wrap leading-relaxed" style={{ color: 'var(--muted-foreground)' }}>
                 {detailAssessment.description}
               </p>
             </div>
          )}
          
          <div className="rounded-xl p-4" style={{ background: '#EFF6FF', border: '1px solid #BFDBFE' }}>
            <p className="text-xs font-semibold mb-1" style={{ color: '#1E40AF' }}>
              Submission Mode: {detailAssessment.submission_mode || 'Individual'}
            </p>
            <p className="text-xs" style={{ color: '#1D4ED8' }}>
              Students in {group?.name || 'this group'} push their solutions to GitHub repositories matching slug <strong>{detailAssessment.repo_slug || detailAssessment.title}</strong>.
            </p>
          </div>

          {/* Student Status List */}
          <div className="rounded-xl overflow-hidden" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
            <div className="px-5 py-3 border-b" style={{ borderColor: 'var(--border)', background: 'var(--muted)' }}>
              <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>Student Overview</p>
            </div>
            <table className="w-full">
              <thead>
                <tr style={{ borderBottom: '1px solid var(--border)', background: 'var(--muted)' }}>
                  {['Student / Team', 'Status', 'Grade'].map(h => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {subs.length === 0 ? (
                  <tr>
                    <td colSpan={3} className="px-4 py-8 text-center text-sm text-gray-400">No students found.</td>
                  </tr>
                ) : (
                  subs.map((s, i) => (
                    <tr 
                      key={s.id} 
                      onClick={() => onNavigate('aievaluations', s.id)}
                      className="cursor-pointer hover:bg-gray-50 transition-colors"
                      style={{ borderBottom: i < subs.length - 1 ? '1px solid var(--border)' : 'none' }}
                    >
                      <td className="px-4 py-3.5 text-sm font-medium text-indigo-600">{s.student_name || `Student #${s.student_id}`}</td>
                      <td className="px-4 py-3.5"><StatusPill status={s.status} /></td>
                      <td className="px-4 py-3.5 text-sm font-bold mono">
                        {s.final_score ?? s.ai_score ?? '-'} / {detailAssessment.max_score}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'rubric' && (
        <div className="rounded-xl overflow-hidden" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <div className="px-5 py-4 border-b flex items-center justify-between" style={{ borderColor: 'var(--border)' }}>
            <div>
              <p className="text-sm font-semibold">{detailAssessment.criteria?.length || 0} criteria · {detailAssessment.max_score} pts total</p>
              <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>Evaluated automatically by Gemini AI and reviewed by instructors.</p>
            </div>
          </div>
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)', background: 'var(--muted)' }}>
                {['#', 'Criterion', 'Description', 'Max Points'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(!detailAssessment.criteria || detailAssessment.criteria.length === 0) ? (
                <tr>
                  <td colSpan={4} className="px-4 py-6 text-center text-sm text-gray-400">No grading criteria defined.</td>
                </tr>
              ) : (
                detailAssessment.criteria.map((c, i) => (
                  <tr key={c.id || i} style={{ borderBottom: i < (detailAssessment.criteria?.length || 0) - 1 ? '1px solid var(--border)' : 'none' }}>
                    <td className="px-4 py-3.5 text-xs mono" style={{ color: 'var(--muted-foreground)' }}>{c.sort_order || i + 1}</td>
                    <td className="px-4 py-3.5 text-sm font-medium">{c.name}</td>
                    <td className="px-4 py-3.5 text-xs" style={{ color: 'var(--muted-foreground)', maxWidth: '260px' }}>{c.description || '—'}</td>
                    <td className="px-4 py-3.5 text-sm mono font-semibold">{c.max_score} pts</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'submissions' && (
        <div className="rounded-xl overflow-hidden" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <div className="px-5 py-3 border-b" style={{ borderColor: 'var(--border)', background: 'var(--muted)' }}>
            <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>Student Submissions</p>
          </div>
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: '1px solid var(--border)', background: 'var(--muted)' }}>
                {['Student / Team', 'Repository', 'Submitted At', 'Status', 'Grade'].map(h => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {subs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-sm text-gray-400">No submissions recorded yet.</td>
                </tr>
              ) : (
                subs.map((s, i) => (
                  <tr key={s.id} onClick={() => onNavigate('aievaluations', s.id)} className="cursor-pointer hover:bg-gray-50" style={{ borderBottom: i < subs.length - 1 ? '1px solid var(--border)' : 'none' }}>
                    <td className="px-4 py-3.5 text-sm font-medium">{s.student_name || `Student #${s.student_id}`}</td>
                    <td className="px-4 py-3.5" onClick={e => e.stopPropagation()}>
                      {s.github_repo_url ? (
                        <a href={s.github_repo_url} target="_blank" rel="noreferrer" className="text-xs mono text-indigo-600 hover:underline">
                          ⎇ {s.github_repo_url}
                        </a>
                      ) : <span className="text-xs text-gray-400">—</span>}
                    </td>
                    <td className="px-4 py-3.5 text-xs mono" style={{ color: 'var(--muted-foreground)' }}>
                      {s.submitted_at ? new Date(s.submitted_at).toLocaleDateString() : '—'}
                    </td>
                    <td className="px-4 py-3.5"><StatusPill status={s.status} /></td>
                    <td className="px-4 py-3.5 text-sm font-bold mono">
                      {s.final_score ?? s.ai_score ?? '-'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'evaluations' && (
        <div className="space-y-3">
          {subs.filter(s => s.ai_score !== null && s.ai_score !== undefined).length === 0 ? (
            <div className="rounded-xl py-16 text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
              <p className="text-2xl mb-2">✦</p>
              <p className="font-medium" style={{ color: 'var(--muted-foreground)' }}>No AI evaluations yet</p>
              <p className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>Evaluations will appear once GitHub submissions are polled and analyzed.</p>
            </div>
          ) : (
            subs.filter(s => s.ai_score !== null).map(s => (
              <div key={s.id} onClick={() => onNavigate('aievaluations', s.id)} className="rounded-xl p-5 cursor-pointer hover:border-indigo-300 transition-colors" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold text-sm">{s.student_name || `Student #${s.student_id}`}</h3>
                    <p className="text-xs mono text-gray-400">{s.github_repo_url}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-lg font-bold mono text-emerald-600">{s.final_score ?? s.ai_score}</span>
                    <span className="text-xs text-gray-400">/{detailAssessment.max_score} pts</span>
                  </div>
                </div>
                {s.ai_feedback && (
                  <div className="mt-3 p-3 bg-gray-50 rounded-lg text-xs text-gray-700 whitespace-pre-wrap">
                    <strong>AI Feedback:</strong> {s.ai_feedback}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}

      {tab === 'results' && (
        <div className="rounded-xl py-16 text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <p className="text-2xl mb-2">📊</p>
          <p className="font-medium" style={{ color: 'var(--muted-foreground)' }}>Gradebook & Analytics</p>
          <p className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>Approved grades will automatically flow into student competency history.</p>
        </div>
      )}
    </div>
  )
}

/* ────────────────────────────────────────────────────────────────────
   Create/Edit Assessment Wizard
───────────────────────────────────────────────────────────────────── */

const STEPS = ['Group & Mode', 'Details', 'Rubric Criteria', 'Review & Publish'] as const
type WizardStep = 0 | 1 | 2 | 3

function CreateWizard({ groups, initialData, onClose, onCreated }: { groups: Group[]; initialData?: Assessment | null; onClose: () => void; onCreated: () => void }) {
  const [step, setStep] = useState<WizardStep>(0)
  const [saving, setSaving] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const safeGroups = groups.length > 0 ? groups : [{ id: 1, name: 'Default Cohort', course_id: 1 }]
  const isEditing = !!initialData

  const [form, setForm] = useState({
    groupId: initialData ? String(initialData.group_id) : (safeGroups[0]?.id ? String(safeGroups[0].id) : '1'),
    mode: (initialData?.submission_mode || 'Individual') as SubmissionMode,
    title: initialData?.title || '',
    description: initialData?.description || '',
    type: initialData?.type || 'Assignment',
    repoSlug: initialData?.repo_slug || '',
    assessmentDate: initialData?.assessment_date?.split('T')[0] || '',
    dueDate: initialData?.due_date?.split('T')[0] || '',
    maxScore: initialData ? String(initialData.max_score) : '100',
    rubric: initialData?.criteria?.length ? initialData.criteria.map(c => ({
      name: c.name, description: c.description || '', maxScore: c.max_score
    })) : [
      { name: 'Code Quality & Structure', description: 'Clean architecture and readability', maxScore: 50 },
      { name: 'Functional Correctness', description: 'Meets requirements without bugs', maxScore: 50 },
    ]
  })

  const set = (k: string, v: any) => setForm(p => ({ ...p, [k]: v }))

  function validate() {
    const e: Record<string, string> = {}
    if (step === 0 && !form.groupId) e.groupId = 'Please select a group'
    if (step === 1) {
      if (!form.title.trim()) e.title = 'Title is required'
      if (!form.dueDate) e.dueDate = 'Due date is required'
      if (!form.maxScore || isNaN(Number(form.maxScore))) e.maxScore = 'Enter a valid number'
    }
    if (step === 2) {
      form.rubric.forEach((r, i) => { if (!r.name.trim()) e[`rname-${i}`] = 'Name is required' })
      const total = form.rubric.reduce((s, r) => s + Number(r.maxScore || 0), 0)
      if (total !== Number(form.maxScore)) e.rubricTotal = `Criterion scores must sum to ${form.maxScore} (currently ${total})`
    }
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handlePublish = async () => {
    setSaving(true)
    try {
      const payload = {
        group_id: Number(form.groupId),
        title: form.title.trim(),
        description: form.description.trim() || null,
        type: form.type.toLowerCase(),
        submission_mode: form.mode.toLowerCase(),
        repo_slug: form.repoSlug.trim() || null,
        assessment_date: form.assessmentDate || null,
        due_date: form.dueDate || null,
        max_score: Number(form.maxScore),
        criteria: form.rubric.map((r, i) => ({
          name: r.name.trim(),
          description: r.description.trim() || null,
          max_score: Number(r.maxScore),
          sort_order: i + 1
        }))
      }

      if (isEditing) {
        await apiFetch(`/assessments/${initialData.id}`, { method: 'PUT', body: JSON.stringify(payload) })
      } else {
        await apiFetch('/assessments', { method: 'POST', body: JSON.stringify(payload) })
      }

      onCreated()
      onClose()
    } catch (err: any) {
      alert(err.message || 'Failed to save assessment')
    } finally {
      setSaving(false)
    }
  }

  const selectedGroup = safeGroups.find(g => String(g.id) === String(form.groupId))
  const rubricTotal = form.rubric.reduce((s, r) => s + Number(r.maxScore || 0), 0)

  return (
    <div>
      {/* Step Indicator */}
      <div className="flex items-center gap-0 mb-6">
        {STEPS.map((label, i) => {
          const done = i < step
          const active = i === step
          return (
            <div key={label} className="flex items-center">
              <div className="flex flex-col items-center">
                <div
                  className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold"
                  style={{ background: done ? '#15803D' : active ? 'var(--primary)' : 'var(--secondary)', color: done || active ? 'white' : 'var(--muted-foreground)' }}
                >
                  {done ? '✓' : i + 1}
                </div>
                <span className="text-xs mt-1 whitespace-nowrap" style={{ color: active ? 'var(--foreground)' : 'var(--muted-foreground)', fontWeight: active ? 600 : 400 }}>{label}</span>
              </div>
              {i < STEPS.length - 1 && <div className="h-px w-8 mx-1 mb-5 flex-shrink-0" style={{ background: i < step ? '#15803D' : 'var(--border)' }} />}
            </div>
          )
        })}
      </div>

      {step === 0 && (
        <div className="space-y-5">
          <div>
            <label className="block text-xs font-semibold mb-1.5 uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>Target Group <span style={{ color: '#EF4444' }}>*</span></label>
            <select
              value={form.groupId}
              onChange={e => set('groupId', e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg text-sm"
              style={{ border: `1px solid ${errors.groupId ? '#EF4444' : 'var(--border)'}`, background: 'var(--muted)', outline: 'none' }}
              disabled={isEditing}
            >
              <option value="">Select a cohort…</option>
              {safeGroups.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
            {errors.groupId && <p className="text-xs mt-1" style={{ color: '#EF4444' }}>{errors.groupId}</p>}
          </div>

          <div>
            <label className="block text-xs font-semibold mb-2 uppercase tracking-wider" style={{ color: 'var(--muted-foreground)' }}>Submission Mode</label>
            <div className="grid grid-cols-2 gap-3">
              {(['Individual', 'Team'] as SubmissionMode[]).map(mode => {
                const active = form.mode === mode
                return (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => set('mode', mode)}
                    className="p-4 rounded-xl text-left"
                    style={{ border: `2px solid ${active ? 'var(--primary)' : 'var(--border)'}`, background: active ? '#EFF6FF' : 'var(--muted)', cursor: 'pointer' }}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-semibold" style={{ color: active ? 'var(--primary)' : 'var(--foreground)' }}>{mode}</span>
                    </div>
                    <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>
                      {mode === 'Individual' ? 'Each student submits a repository.' : 'One shared repository per team.'}
                    </p>
                  </button>
                )
              })}
            </div>
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="space-y-3">
          <div>
            <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted-foreground)' }}>Title <span style={{ color: '#EF4444' }}>*</span></label>
            <input
              value={form.title}
              onChange={e => set('title', e.target.value)}
              placeholder="e.g. Full Stack Authentication API"
              className="w-full px-3 py-2.5 rounded-lg text-sm"
              style={{ border: `1px solid ${errors.title ? '#EF4444' : 'var(--border)'}`, background: 'var(--muted)', outline: 'none' }}
            />
            {errors.title && <p className="text-xs mt-1" style={{ color: '#EF4444' }}>{errors.title}</p>}
          </div>

          <div>
            <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted-foreground)' }}>GitHub Repo Slug (for automatic AI polling)</label>
            <input
              value={form.repoSlug}
              onChange={e => set('repoSlug', e.target.value)}
              placeholder="e.g. backend-auth-milestone"
              className="w-full px-3 py-2.5 rounded-lg text-sm"
              style={{ border: '1px solid var(--border)', background: 'var(--muted)', outline: 'none' }}
            />
          </div>

          <div>
            <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted-foreground)' }}>Instructions / Description</label>
            <textarea
              value={form.description}
              onChange={e => set('description', e.target.value)}
              rows={4}
              placeholder="Detailed guidelines and prompt context for Gemini AI..."
              className="w-full px-3 py-2.5 rounded-lg text-sm resize-none whitespace-pre-wrap"
              style={{ border: '1px solid var(--border)', background: 'var(--muted)', outline: 'none' }}
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted-foreground)' }}>Due Date <span style={{ color: '#EF4444' }}>*</span></label>
              <input
                type="date"
                value={form.dueDate}
                onChange={e => set('dueDate', e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg text-sm"
                style={{ border: `1px solid ${errors.dueDate ? '#EF4444' : 'var(--border)'}`, background: 'var(--muted)', outline: 'none' }}
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted-foreground)' }}>Assessment Date</label>
              <input
                type="date"
                value={form.assessmentDate}
                onChange={e => set('assessmentDate', e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg text-sm"
                style={{ border: '1px solid var(--border)', background: 'var(--muted)', outline: 'none' }}
              />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1" style={{ color: 'var(--muted-foreground)' }}>Max Score</label>
              <input
                type="number"
                value={form.maxScore}
                onChange={e => set('maxScore', e.target.value)}
                className="w-full px-3 py-2.5 rounded-lg text-sm"
                style={{ border: `1px solid ${errors.maxScore ? '#EF4444' : 'var(--border)'}`, background: 'var(--muted)', outline: 'none' }}
              />
            </div>
          </div>
        </div>
      )}

      {step === 2 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <p className="text-sm font-medium">Evaluation Criteria</p>
              <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>Rubric scores must total {form.maxScore} pts.</p>
            </div>
            <button
              type="button"
              onClick={() => set('rubric', [...form.rubric, { name: '', description: '', maxScore: 10 }])}
              className="text-xs px-3 py-1.5 rounded-lg font-medium"
              style={{ border: '1px solid var(--border)', background: 'transparent', cursor: 'pointer' }}
            >
              + Add Criterion
            </button>
          </div>

          <div className="space-y-2 mb-3 max-h-60 overflow-y-auto pr-1">
            {form.rubric.map((r, i) => (
              <div key={i} className="flex items-start gap-2 rounded-lg p-2.5" style={{ border: '1px solid var(--border)', background: 'var(--muted)' }}>
                <span className="text-xs mono pt-2 w-4 text-center" style={{ color: 'var(--muted-foreground)' }}>{i + 1}</span>
                <div className="flex-1 grid grid-cols-1 gap-2">
                  <input
                    value={r.name}
                    onChange={e => { const next = [...form.rubric]; next[i].name = e.target.value; set('rubric', next) }}
                    placeholder="Criterion name"
                    className="w-full px-2 py-1.5 rounded text-xs"
                    style={{ border: `1px solid ${errors[`rname-${i}`] ? '#EF4444' : 'var(--border)'}`, background: 'var(--card)', outline: 'none' }}
                  />
<textarea
  value={r.description}
  onChange={e => {
    const next = [...form.rubric]
    next[i].description = e.target.value
    set('rubric', next)
  }}
  placeholder="Describe how this criterion will be evaluated..."
  rows={4}
  className="w-full px-2 py-2 rounded text-xs resize-y"
  style={{
    border: '1px solid var(--border)',
    background: 'var(--card)',
    outline: 'none'
  }}
/>
                  <input
                    type="number"
                    value={r.maxScore}
                    onChange={e => { const next = [...form.rubric]; next[i].maxScore = Number(e.target.value); set('rubric', next) }}
                    placeholder="Points"
                    className="w-full px-2 py-1.5 rounded text-xs"
                    style={{ border: '1px solid var(--border)', background: 'var(--card)', outline: 'none' }}
                  />
                </div>
                <button
                  type="button"
                  onClick={() => set('rubric', form.rubric.filter((_, idx) => idx !== i))}
                  disabled={form.rubric.length <= 1}
                  className="text-xs pt-1.5 px-1 text-red-500 hover:text-red-700"
                >✕</button>
              </div>
            ))}
          </div>

          <div className="flex justify-between px-1">
            <span className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{form.rubric.length} criteria</span>
            <span className="text-xs font-semibold mono" style={{ color: rubricTotal === Number(form.maxScore) ? '#15803D' : '#B45309' }}>
              Total: {rubricTotal} / {form.maxScore} pts
            </span>
          </div>
          {errors.rubricTotal && <p className="text-xs mt-2" style={{ color: '#EF4444' }}>{errors.rubricTotal}</p>}
        </div>
      )}

      {step === 3 && (
        <div className="space-y-4">
          <div className="rounded-xl p-4" style={{ background: 'var(--muted)', border: '1px solid var(--border)' }}>
            <p className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: 'var(--muted-foreground)' }}>Summary</p>
            {[
              ['Target Cohort', selectedGroup?.name ?? '—'],
              ['Submission Mode', form.mode],
              ['Title', form.title],
              ['Repo Slug', form.repoSlug || '—'],
              ['Due Date', form.dueDate],
              ['Max Score', `${form.maxScore} pts`],
              ['Rubric Criteria', `${form.rubric.length} items`]
            ].map(([l, v]) => (
              <div key={l} className="flex justify-between text-sm py-1">
                <span style={{ color: 'var(--muted-foreground)' }}>{l}</span>
                <span className="font-medium">{v}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex gap-3 mt-6 pt-4" style={{ borderTop: '1px solid var(--border)' }}>
        <button
          type="button"
          onClick={() => { if (step === 0) onClose(); else { setErrors({}); setStep(s => (s - 1) as WizardStep) } }}
          className="px-5 py-2.5 rounded-lg text-sm"
          style={{ border: '1px solid var(--border)', background: 'transparent', cursor: 'pointer' }}
        >
          {step === 0 ? 'Cancel' : '← Back'}
        </button>
        <div className="flex-1" />
        {step < 3 ? (
          <button
            type="button"
            onClick={() => { if (validate()) setStep(s => (s + 1) as WizardStep) }}
            className="px-6 py-2.5 rounded-lg text-sm font-semibold"
            style={{ background: 'var(--primary)', color: 'white', border: 'none', cursor: 'pointer' }}
          >
            {step === 2 ? 'Review & Publish →' : 'Continue →'}
          </button>
        ) : (
          <button
            type="button"
            onClick={handlePublish}
            disabled={saving}
            className="px-6 py-2.5 rounded-lg text-sm font-semibold"
            style={{ background: '#15803D', color: 'white', border: 'none', cursor: saving ? 'not-allowed' : 'pointer' }}
          >
            {saving ? 'Saving…' : (isEditing ? 'Save Changes' : 'Publish Assessment')}
          </button>
        )}
      </div>
    </div>
  )
}

/* ────────────────────────────────────────────────────────────────────
   Main Teacher Assessments Page
───────────────────────────────────────────────────────────────────── */

export default function TeacherAssessments({ onNavigate }: Props) {
  const [assessments, setAssessments] = useState<Assessment[]>([])
  const [groups, setGroups] = useState<Group[]>([])
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [selectedAssessment, setSelectedAssessment] = useState<Assessment | null>(null)
  
  const [showCreate, setShowCreate] = useState(false)
  const [wizardData, setWizardData] = useState<Assessment | null>(null)
  
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  // Filters
  const [filterGroup, setFilterGroup] = useState('all')
  const [filterMode, setFilterMode] = useState<string>('all')
  const [filterType, setFilterType] = useState('all')

  const loadData = async () => {
    setLoading(true)
    setError('')
    try {
      // The API calls should return filtered results based on the logged-in teacher's token.
      const [assRes, grpRes, subRes] = await Promise.all([
        apiFetch('/assessments').catch(() => ({ data: [] })),
        apiFetch('/groups').catch(() => ({ data: [] })),
        apiFetch('/submissions').catch(() => ({ data: [] }))
      ])
      
      setAssessments(assRes.data || (Array.isArray(assRes) ? assRes : []))
      setGroups(grpRes.data || (Array.isArray(grpRes) ? grpRes : []))
      setSubmissions(subRes.data || (Array.isArray(subRes) ? subRes : []))
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Failed to load assessments')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadData()
  }, [])

  const filtered = useMemo(() => assessments.filter(a => {
    if (filterGroup !== 'all' && String(a.group_id) !== filterGroup) return false
    if (filterMode !== 'all' && a.submission_mode?.toLowerCase() !== filterMode.toLowerCase()) return false
    if (filterType !== 'all' && a.type?.toLowerCase() !== filterType.toLowerCase()) return false
    return true
  }), [assessments, filterGroup, filterMode, filterType])

  const byGroup = useMemo(() => {
    const map = new Map<number, { group: Group; assessments: Assessment[] }>()
    groups.forEach(g => map.set(g.id, { group: g, assessments: [] }))
    filtered.forEach(a => {
      const target = map.get(a.group_id)
      if (target) target.assessments.push(a)
      else map.set(a.group_id, { group: { id: a.group_id, name: a.group_name || `Group #${a.group_id}`, course_id: 1 }, assessments: [a] })
    })
    return [...map.values()].filter(v => v.assessments.length > 0)
  }, [groups, filtered])

  const openWizardForEdit = async (a: Assessment) => {
    try {
      const response = await apiFetch(`/assessments/${a.id}`)
      setWizardData(response.data || a)
      setShowCreate(true)
    } catch (err: any) {
      alert(err?.message || 'Could not load assignment for editing')
    }
  }

  const openWizardForCreate = () => {
    setWizardData(null)
    setShowCreate(true)
  }
  if (selectedAssessment) {
    return (
      <>
        <AssessmentDetail
          a={selectedAssessment}
          groups={groups}
          allSubs={submissions}
          onBack={() => setSelectedAssessment(null)}
          onDeleted={() => {
            setSelectedAssessment(null)
            loadData()
          }}
          onEdit={openWizardForEdit}
          onNavigate={onNavigate}
        />

        {/* EDIT ASSESSMENT MODAL */}
        {showCreate && (
          <div
            className="fixed inset-0 flex items-center justify-center z-50 p-4"
            style={{
              background: 'rgba(0,0,0,0.4)'
            }}
            onClick={() => setShowCreate(false)}
          >
            <div
              className="rounded-xl p-6 w-full max-w-xl max-h-[90vh] overflow-y-auto"
              style={{
                background: 'var(--card)',
                border: '1px solid var(--border)',
                boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
              }}
              onClick={e => e.stopPropagation()}
            >
              <h2
                className="text-lg font-semibold mb-5"
                style={{
                  fontFamily: 'Outfit, sans-serif'
                }}
              >
                Edit Assessment
              </h2>

              <CreateWizard
                groups={groups}
                initialData={wizardData}
                onClose={() => setShowCreate(false)}
                onCreated={async () => {
                  await loadData()

                  if (selectedAssessment) {
                    try {
                      const response = await apiFetch(
                        `/assessments/${selectedAssessment.id}`
                      )

                      setSelectedAssessment(
                        response.data || selectedAssessment
                      )
                    } catch {
                      // Keep the current assessment if refresh fails
                    }
                  }

                  setShowCreate(false)
                }}
              />
            </div>
          </div>
        )}
      </>
    )
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">

      {/* PAGE HEADER */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1
            className="text-2xl font-semibold"
            style={{
              fontFamily: 'Outfit, sans-serif'
            }}
          >
            Assessments
          </h1>

          <p
            className="text-sm mt-0.5"
            style={{
              color: 'var(--muted-foreground)'
            }}
          >
            {assessments.length} assessments across {groups.length} groups
          </p>
        </div>

        <button
          onClick={openWizardForCreate}
          className="text-sm font-semibold px-4 py-2 rounded-lg"
          style={{
            background: 'var(--primary)',
            color: 'white',
            border: 'none',
            cursor: 'pointer'
          }}
        >
          + New Assessment
        </button>
      </div>

      {/* ERROR */}
      {error && (
        <p
          className="text-xs rounded-lg px-3 py-2.5 mb-4"
          style={{
            background: '#FEE2E2',
            color: '#B91C1C'
          }}
        >
          {error}
        </p>
      )}

      {/* FILTER BAR */}
      <div
        className="flex flex-wrap gap-3 mb-6 p-4 rounded-xl"
        style={{
          background: 'var(--card)',
          border: '1px solid var(--border)'
        }}
      >
        {/* GROUP FILTER */}
        <div className="flex items-center gap-2">
          <label
            className="text-xs font-medium"
            style={{
              color: 'var(--muted-foreground)'
            }}
          >
            Group
          </label>

          <select
            value={filterGroup}
            onChange={e => setFilterGroup(e.target.value)}
            className="text-sm px-2.5 py-1.5 rounded-lg"
            style={{
              border: '1px solid var(--border)',
              background: 'var(--muted)',
              outline: 'none'
            }}
          >
            <option value="all">
              All Groups
            </option>

            {groups.map(g => (
              <option
                key={g.id}
                value={String(g.id)}
              >
                {g.name}
              </option>
            ))}
          </select>
        </div>

        {/* MODE FILTER */}
        <div className="flex items-center gap-2">
          <label
            className="text-xs font-medium"
            style={{
              color: 'var(--muted-foreground)'
            }}
          >
            Mode
          </label>

          <select
            value={filterMode}
            onChange={e => setFilterMode(e.target.value)}
            className="text-sm px-2.5 py-1.5 rounded-lg"
            style={{
              border: '1px solid var(--border)',
              background: 'var(--muted)',
              outline: 'none'
            }}
          >
            <option value="all">
              All Modes
            </option>

            <option value="individual">
              Individual
            </option>

            <option value="team">
              Team
            </option>
          </select>
        </div>

        {/* TYPE FILTER */}
        <div className="flex items-center gap-2">
          <label
            className="text-xs font-medium"
            style={{
              color: 'var(--muted-foreground)'
            }}
          >
            Type
          </label>

          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="text-sm px-2.5 py-1.5 rounded-lg"
            style={{
              border: '1px solid var(--border)',
              background: 'var(--muted)',
              outline: 'none'
            }}
          >
            <option value="all">
              All Types
            </option>

            <option value="assignment">
              Assignment
            </option>

            <option value="project">
              Project
            </option>

            <option value="presentation">
              Presentation
            </option>

            <option value="practical">
              Practical
            </option>
          </select>
        </div>

        {/* CLEAR FILTERS */}
        {(filterGroup !== 'all' ||
          filterMode !== 'all' ||
          filterType !== 'all') && (
          <button
            onClick={() => {
              setFilterGroup('all')
              setFilterMode('all')
              setFilterType('all')
            }}
            className="text-xs px-2.5 py-1.5 rounded-lg ml-auto"
            style={{
              border: '1px solid var(--border)',
              background: 'transparent',
              cursor: 'pointer',
              color: 'var(--muted-foreground)'
            }}
          >
            Clear filters
          </button>
        )}
      </div>

      {/* ASSESSMENT LIST */}
      {loading ? (
        <p
          className="text-sm"
          style={{
            color: 'var(--muted-foreground)'
          }}
        >
          Loading assessments…
        </p>
      ) : byGroup.length === 0 ? (
        <div
          className="rounded-xl py-16 text-center"
          style={{
            background: 'var(--card)',
            border: '1px solid var(--border)'
          }}
        >
          <p
            className="font-medium"
            style={{
              color: 'var(--muted-foreground)'
            }}
          >
            No assessments found.
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          {byGroup.map(({ group, assessments }) => (
            <div key={group.id}>

              {/* GROUP HEADER */}
              <div className="flex items-center gap-3 mb-3">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                  style={{
                    background: 'var(--primary)'
                  }}
                >
                  {group.name.charAt(0)}
                </div>

                <div>
                  <h2
                    className="text-base font-semibold"
                    style={{
                      fontFamily: 'Outfit, sans-serif'
                    }}
                  >
                    {group.name}
                  </h2>

                  <p
                    className="text-xs"
                    style={{
                      color: 'var(--muted-foreground)'
                    }}
                  >
                    {assessments.length} assessment
                    {assessments.length !== 1 ? 's' : ''}
                  </p>
                </div>
              </div>

              {/* CARDS */}
              <div
                className="grid gap-3"
                style={{
                  gridTemplateColumns:
                    'repeat(auto-fill, minmax(280px, 1fr))'
                }}
              >
                {assessments.map(a => (
                  <AssessmentCard
                    key={a.id}
                    a={a}
                    subs={submissions}
                    onClick={() =>
                      setSelectedAssessment(a)
                    }
                  />
                ))}
              </div>

            </div>
          ))}
        </div>
      )}

      {/* CREATE ASSESSMENT MODAL */}
      {showCreate && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50 p-4"
          style={{
            background: 'rgba(0,0,0,0.4)'
          }}
          onClick={() => setShowCreate(false)}
        >
          <div
            className="rounded-xl p-6 w-full max-w-xl max-h-[90vh] overflow-y-auto"
            style={{
              background: 'var(--card)',
              border: '1px solid var(--border)',
              boxShadow: '0 20px 60px rgba(0,0,0,0.2)'
            }}
            onClick={e => e.stopPropagation()}
          >
            <h2
              className="text-lg font-semibold mb-5"
              style={{
                fontFamily: 'Outfit, sans-serif'
              }}
            >
              Create Assessment
            </h2>

            <CreateWizard
              groups={groups}
              initialData={null}
              onClose={() =>
                setShowCreate(false)
              }
              onCreated={() => {
                loadData()
                setShowCreate(false)
              }}
            />
          </div>
        </div>
      )}
    </div>
  )
}