import { useEffect, useState } from 'react'
import jsPDF from 'jspdf'
import { getMyGroups, getGroupStudents, getStudentReport } from '../../lib/api'

type ScopedStudent = { id: string; name: string }

const SECTIONS = [
  { id: 'attendance', label: 'Attendance Records', icon: '✓', desc: 'Full session-by-session attendance history' },
  { id: 'scores', label: 'Assessment Scores', icon: '📝', desc: 'Rubric scores and totals for all assessments' },
  { id: 'quiz', label: 'Quiz Results', icon: '❓', desc: 'All quiz scores by topic and date' },
  { id: 'competency', label: 'Competency Matrix', icon: '⬡', desc: 'Skill-by-skill progress levels' },
  { id: 'feedback', label: 'Teacher Feedback', icon: '✦', desc: 'Written feedback shared with the student' },
  { id: 'certificates', label: 'Certificates', icon: '🏆', desc: 'Issued certificates and expiry dates' },
] as const

type SectionId = (typeof SECTIONS)[number]['id']

function buildPdf(student: { name: string; email: string }, data: any, included: Set<SectionId>) {
  const doc = new jsPDF()
  const marginX = 14
  const pageHeight = doc.internal.pageSize.getHeight()
  const pageWidth = doc.internal.pageSize.getWidth()
  let y = 20

  const ensureSpace = (needed: number) => {
    if (y + needed > pageHeight - 15) {
      doc.addPage()
      y = 20
    }
  }

  const heading = (text: string) => {
    ensureSpace(14)
    doc.setFontSize(13)
    doc.setFont('helvetica', 'bold')
    doc.text(text, marginX, y)
    y += 7
    doc.setDrawColor(220)
    doc.line(marginX, y, pageWidth - marginX, y)
    y += 6
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(10)
  }

  const line = (text: string) => {
    const wrapped = doc.splitTextToSize(text, pageWidth - marginX * 2)
    wrapped.forEach((l: string) => {
      ensureSpace(6)
      doc.text(l, marginX, y)
      y += 5.5
    })
  }

  // Header
  doc.setFontSize(16)
  doc.setFont('helvetica', 'bold')
  doc.text('Lexicon Institute', marginX, y)
  y += 6
  doc.setFontSize(11)
  doc.setFont('helvetica', 'normal')
  doc.text('Student Performance Report', marginX, y)
  y += 8

  doc.setFontSize(12)
  doc.setFont('helvetica', 'bold')
  doc.text(student.name, marginX, y)
  y += 5.5
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.setTextColor(100)
  doc.text(student.email, marginX, y)
  doc.setTextColor(0)
  y += 5
  doc.text(`Generated: ${new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}`, marginX, y)
  y += 10

  if (included.has('attendance')) {
    heading('Attendance Records')
    const rows = data.attendance || []
    if (!rows.length) line('No attendance records.')
    rows.slice(0, 60).forEach((r: any) => {
      line(`${r.attendance_date}  ·  ${r.session}  ·  ${r.status}${r.note ? `  ·  ${r.note}` : ''}`)
    })
    y += 4
  }

  if (included.has('scores')) {
    heading('Assessment Scores')
    const rows = data.scores || []
    if (!rows.length) line('No assessment scores.')
    rows.forEach((r: any) => {
      line(`${r.assessment_title}: ${r.score} / ${r.max_score}`)
    })
    y += 4
  }

  if (included.has('quiz')) {
    heading('Quiz Results')
    const rows = data.quizzes || []
    if (!rows.length) line('No quiz results.')
    rows.forEach((r: any) => {
      line(`${r.quiz_title} (${r.topic || '—'}): ${r.score} / ${r.max_score}`)
    })
    y += 4
  }

  if (included.has('competency')) {
    heading('Competency Matrix')
    const rows = data.competencies || []
    if (!rows.length) line('No competency data.')
    rows.forEach((r: any) => {
      line(`${r.name}: ${r.score}%`)
    })
    y += 4
  }

  if (included.has('feedback')) {
    heading('Teacher Feedback')
    const rows = data.feedback || []
    if (!rows.length) line('No feedback recorded.')
    rows.forEach((r: any) => {
      doc.setFont('helvetica', 'bold')
      line(`${r.teacher_name} — ${new Date(r.created_at).toLocaleDateString('en-GB')}`)
      doc.setFont('helvetica', 'normal')
      line(r.content)
      y += 2
    })
    y += 2
  }

  if (included.has('certificates')) {
    heading('Certificates')
    const rows = data.certificates || []
    if (!rows.length) line('No certificates issued.')
    rows.forEach((r: any) => {
      line(`${r.name} — ${r.issuing_organization || '—'} (${r.issue_date || '—'}${r.expiry_date ? ` – ${r.expiry_date}` : ''})`)
    })
  }

  return doc
}

export default function TeacherReports() {
  const [students, setStudents] = useState<ScopedStudent[]>([])
  const [selectedStudentId, setSelectedStudentId] = useState('')
  const [included, setIncluded] = useState<Set<SectionId>>(new Set(SECTIONS.map((s) => s.id)))
  const [loading, setLoading] = useState(true)
  const [generating, setGenerating] = useState(false)
  const [generated, setGenerated] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true)
        setError('')

        const groupsRes = await getMyGroups()
        const groups = Array.isArray(groupsRes?.data) ? groupsRes.data : []

        const studentLists = await Promise.all(groups.map((g: any) => getGroupStudents(g.id)))

        const byId = new Map<string, ScopedStudent>()
        studentLists.forEach((res) => {
          const list = Array.isArray(res?.data) ? res.data : []
          list.forEach((s: any) => byId.set(String(s.id), { id: String(s.id), name: s.name }))
        })

        const list = Array.from(byId.values()).sort((a, b) => a.name.localeCompare(b.name))
        setStudents(list)
        if (list.length) setSelectedStudentId(list[0].id)
      } catch (err: any) {
        setError(err?.message || 'Failed to load students')
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [])

  const toggleSection = (id: SectionId) => {
    setIncluded((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
    setGenerated(false)
  }

  const handleGenerate = async () => {
    if (!selectedStudentId) return

    try {
      setGenerating(true)
      setGenerated(false)
      setError('')

      const res = await getStudentReport(selectedStudentId)
      const data = res?.data
      if (!data?.student) throw new Error('No report data returned')

      const doc = buildPdf(data.student, data, included)
      const safeName = data.student.name.replace(/[^a-z0-9]+/gi, '_')
      doc.save(`${safeName}_report.pdf`)

      setGenerated(true)
    } catch (err: any) {
      setError(err?.message || 'Failed to generate report')
    } finally {
      setGenerating(false)
    }
  }

  const student = students.find((s) => s.id === selectedStudentId)

  if (loading) {
    return <div className="p-6">Loading...</div>
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold" style={{ fontFamily: 'Outfit, sans-serif' }}>PDF Reports</h1>
        <p className="text-sm mt-0.5" style={{ color: 'var(--muted-foreground)' }}>Generate and download performance reports for your own students</p>
      </div>

      {error && (
        <div className="p-4 rounded-xl text-sm mb-6" style={{ background: '#FEE2E2', color: '#B91C1C' }}>
          {error}
        </div>
      )}

      {!students.length ? (
        <div className="p-10 rounded-xl text-center" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
          <p className="font-medium">You have no students yet.</p>
          <p className="text-sm mt-1" style={{ color: 'var(--muted-foreground)' }}>
            Reports can be generated once you are assigned to a group with students.
          </p>
        </div>
      ) : (
        <div className="grid gap-6" style={{ gridTemplateColumns: '1fr 320px' }}>
          {/* Config */}
          <div className="space-y-4">
            <div className="rounded-xl p-5" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
              <label className="block text-sm font-semibold mb-3" style={{ fontFamily: 'Outfit, sans-serif' }}>Student</label>
              <select
                value={selectedStudentId}
                onChange={(e) => { setSelectedStudentId(e.target.value); setGenerated(false) }}
                className="w-full px-3 py-2.5 rounded-lg text-sm"
                style={{ border: '1px solid var(--border)', background: 'var(--muted)', outline: 'none', cursor: 'pointer' }}
              >
                {students.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>

            <div className="rounded-xl p-5" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
              <p className="text-sm font-semibold mb-3" style={{ fontFamily: 'Outfit, sans-serif' }}>Include in Report</p>
              <div className="space-y-2">
                {SECTIONS.map((s) => (
                  <label
                    key={s.id}
                    className="flex items-start gap-3 p-3 rounded-lg cursor-pointer transition-colors"
                    style={{
                      background: included.has(s.id) ? 'var(--secondary)' : 'transparent',
                      border: `1px solid ${included.has(s.id) ? 'var(--border)' : 'transparent'}`,
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={included.has(s.id)}
                      onChange={() => toggleSection(s.id)}
                      className="mt-0.5 flex-shrink-0"
                      style={{ accentColor: 'var(--primary)' }}
                    />
                    <div>
                      <p className="text-sm font-medium">{s.icon} {s.label}</p>
                      <p className="text-xs mt-0.5" style={{ color: 'var(--muted-foreground)' }}>{s.desc}</p>
                    </div>
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Preview + action */}
          <div className="space-y-4">
            <div className="rounded-xl p-5" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
              <p className="text-sm font-semibold mb-3" style={{ fontFamily: 'Outfit, sans-serif' }}>Report Preview</p>
              <div className="rounded-lg p-4 mb-4" style={{ background: 'var(--muted)', border: '1px solid var(--border)' }}>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-6 h-6 rounded flex items-center justify-center text-white text-xs font-bold" style={{ background: 'var(--primary)' }}>L</div>
                  <div>
                    <p className="text-xs font-bold" style={{ fontFamily: 'Outfit, sans-serif' }}>Lexicon Institute</p>
                    <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>Student Performance Report</p>
                  </div>
                </div>
                <p className="text-xs font-semibold border-t pt-2" style={{ borderColor: 'var(--border)' }}>{student?.name}</p>
                <p className="text-xs mt-2" style={{ color: 'var(--muted-foreground)' }}>Generated: {new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</p>

                <div className="mt-3 pt-2 border-t space-y-1" style={{ borderColor: 'var(--border)' }}>
                  <p className="text-xs font-medium" style={{ color: 'var(--muted-foreground)' }}>Contents:</p>
                  {SECTIONS.filter((s) => included.has(s.id)).map((s) => (
                    <p key={s.id} className="text-xs">{s.icon} {s.label}</p>
                  ))}
                  {included.size === 0 && <p className="text-xs" style={{ color: '#B91C1C' }}>No sections selected</p>}
                </div>
              </div>

              <button
                onClick={handleGenerate}
                disabled={generating || included.size === 0}
                className="w-full py-3 rounded-lg text-sm font-semibold transition-opacity flex items-center justify-center gap-2"
                style={{
                  background: 'var(--primary)',
                  color: 'white',
                  border: 'none',
                  cursor: generating || included.size === 0 ? 'not-allowed' : 'pointer',
                  opacity: included.size === 0 ? 0.5 : generating ? 0.7 : 1,
                }}
              >
                <span>📄</span>
                {generating ? 'Generating PDF…' : 'Generate & Download PDF'}
              </button>

              {generated && (
                <p className="text-xs text-center mt-2 font-medium" style={{ color: '#15803D' }}>
                  ✓ Report ready — download started
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
