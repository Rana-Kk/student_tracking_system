import { useEffect, useMemo, useState } from 'react'
import {
  createUser,
  deleteUser,
  getCourses,
  getGroups,
  getUsers,
  importStudentsExcel,
  updateUser
} from '../../lib/api'
import { ApiError } from '../../lib/api'

type Student = {
  id: number | string
  name: string
  email: string
  group_ids?: string
  group_names?: string
  course_ids?: string
  course_names?: string
}

function parseCsv(text: string) {
  const lines = text.split(/\r?\n/).filter(Boolean)

  if (!lines.length) return []

  const split = (line: string) =>
    line
      .split(',')
      .map((v) => v.trim().replace(/^"|"$/g, ''))

  const headers = split(lines[0]).map((h) => h.toLowerCase())

  return lines.slice(1).map((line) => {
    const v = split(line)
    const r: Record<string, string> = {}

    headers.forEach((h, i) => {
      r[h] = v[i] ?? ''
    })

    return r
  })
}

export default function AdminStudents() {
  const [students, setStudents] = useState<Student[]>([])
  const [courses, setCourses] = useState<any[]>([])
  const [groups, setGroups] = useState<any[]>([])

  const [modal, setModal] = useState<{
    mode: 'add' | 'edit'
    student?: Student
  } | null>(null)

  const [form, setForm] = useState({
  name: '',
  email: '',
  password: '',
  group_ids: [] as string[]
})

  const [error, setError] = useState('')
  const [importResult, setImportResult] = useState<any>(null)

  // FILTERS
  const [courseFilter, setCourseFilter] = useState('')
  const [groupFilter, setGroupFilter] = useState('')

  const load = async () => {
    try {
      const [s, c, g] = await Promise.all([
        getUsers('student'),
        getCourses(),
        getGroups()
      ])

      setStudents(s.data ?? [])
      setCourses(c.data ?? [])
      setGroups(g.data ?? [])
    } catch (e) {
      setError(
        e instanceof ApiError
          ? e.message
          : 'Could not load students.'
      )
    }
  }

  useEffect(() => {
    load()
  }, [])

  // FILTERED STUDENTS
  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      const courseMatch =
        !courseFilter ||
        (student.course_ids ?? '')
          .split(',')
          .map((id) => id.trim())
          .includes(courseFilter)

      const groupMatch =
        !groupFilter ||
        (student.group_ids ?? '')
          .split(',')
          .map((id) => id.trim())
          .includes(groupFilter)

      return courseMatch && groupMatch
    })
  }, [students, courseFilter, groupFilter])

  const save = async () => {
  try {
    if (!form.name || !form.email) {
      setError('Name and email are required')
      return
    }

    if (modal?.mode === 'add') {
      await createUser({
        name: form.name,
        email: form.email,
        password: form.password || 'Temp1234',
        role: 'student',
        group_ids: form.group_ids.map(Number)
      })
    } else if (modal?.student) {
      await updateUser(modal.student.id, {
        name: form.name,
        email: form.email,
        group_ids: form.group_ids.map(Number)
      })
    }

    setModal(null)
    await load()
  } catch (e) {
    setError(
      e instanceof ApiError
        ? e.message
        : 'Could not save student.'
    )
  }
}

  const remove = async (s: Student) => {
    if (!confirm(`Delete ${s.name}?`)) return

    try {
      await deleteUser(s.id)
      await load()
    } catch (e) {
      setError(
        e instanceof ApiError
          ? e.message
          : 'Could not delete student.'
      )
    }
  }

  const importFile = async (file: File) => {
    setError('')

    try {
      if (file.name.toLowerCase().endsWith('.xlsx')) {
        const bytes = new Uint8Array(
          await file.arrayBuffer()
        )

        let binary = ''

        for (let i = 0; i < bytes.length; i += 0x8000) {
          binary += String.fromCharCode(
            ...bytes.subarray(i, i + 0x8000)
          )
        }

        const r = await importStudentsExcel(
          btoa(binary),
          file.name
        )

        setImportResult(r)
        await load()

        return
      }

      setError('Please upload an .xlsx Excel file.')
    } catch (e) {
      setError(
        e instanceof ApiError
          ? e.message
          : 'Import failed.'
      )
    }
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">

      {/* HEADER */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold">
            Students
          </h1>

          <p
            className="text-sm mt-0.5"
            style={{
              color: 'var(--muted-foreground)'
            }}
          >
            {filteredStudents.length} students shown
          </p>
        </div>

        <div className="flex gap-2">

          <label
            className="text-sm px-4 py-2 rounded-lg cursor-pointer"
            style={{
              border: '1px solid var(--border)'
            }}
          >
            Import Excel

            <input
              type="file"
              accept=".xlsx"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0]

                if (f) {
                  importFile(f)
                }
              }}
            />
          </label>

          <button
            onClick={() => {
              setError('')

              setForm({
                name: '',
                email: '',
                password: '',
                group_ids: []
              })

              setModal({
                mode: 'add'
              })
            }}
            className="text-sm font-semibold px-4 py-2 rounded-lg"
            style={{
              background: 'var(--primary)',
              color: 'white',
              border: 'none'
            }}
          >
            + Add Student
          </button>
        </div>
      </div>

      {/* ERROR */}
      {error && (
        <p
          className="mb-4 text-sm rounded-lg px-3 py-2"
          style={{
            background: '#FEE2E2',
            color: '#B91C1C'
          }}
        >
          {error}
        </p>
      )}

      {/* IMPORT RESULT */}
      {importResult && (
        <div
          className="mb-4 rounded-lg p-3 text-sm"
          style={{
            background: 'var(--secondary)',
            border: '1px solid var(--border)'
          }}
        >
          Imported <b>{importResult.imported}</b>, skipped{' '}
          <b>{importResult.skipped}</b>.

          <br />

          Temporary passwords are returned only in this
          import result.
        </div>
      )}

      {/* FILTERS */}
      <div
        className="rounded-xl p-4 mb-4 flex gap-3"
        style={{
          background: 'var(--card)',
          border: '1px solid var(--border)'
        }}
      >

        {/* COURSE FILTER */}
        <select
          value={courseFilter}
          onChange={(e) =>
            setCourseFilter(e.target.value)
          }
          className="px-3 py-2 rounded-lg text-sm"
          style={{
            border: '1px solid var(--border)',
            background: 'var(--muted)'
          }}
        >
          <option value="">
            All Courses
          </option>

          {courses.map((course) => (
            <option
              key={course.id}
              value={String(course.id)}
            >
              {course.name}
            </option>
          ))}
        </select>

        {/* GROUP FILTER */}
        <select
          value={groupFilter}
          onChange={(e) =>
            setGroupFilter(e.target.value)
          }
          className="px-3 py-2 rounded-lg text-sm"
          style={{
            border: '1px solid var(--border)',
            background: 'var(--muted)'
          }}
        >
          <option value="">
            All Groups
          </option>

          {groups.map((group) => (
            <option
              key={group.id}
              value={String(group.id)}
            >
              {group.name}
            </option>
          ))}
        </select>

        {/* CLEAR FILTERS */}
        {(courseFilter || groupFilter) && (
          <button
            onClick={() => {
              setCourseFilter('')
              setGroupFilter('')
            }}
            className="px-3 py-2 rounded-lg text-sm"
            style={{
              border: '1px solid var(--border)'
            }}
          >
            Clear Filters
          </button>
        )}
      </div>

      {/* STUDENTS TABLE */}
      <div
        className="rounded-xl overflow-hidden"
        style={{
          background: 'var(--card)',
          border: '1px solid var(--border)'
        }}
      >
        <table className="w-full">

          <thead>
            <tr
              style={{
                borderBottom:
                  '1px solid var(--border)'
              }}
            >
              {[
                'Student',
                'Email',
                'Course',
                'Group',
                'Actions'
              ].map((h) => (
                <th
                  key={h}
                  className="px-5 py-3 text-left text-xs uppercase"
                  style={{
                    color:
                      'var(--muted-foreground)'
                  }}
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {filteredStudents.map(
              (s, i) => (
                <tr
                  key={s.id}
                  style={{
                    borderBottom:
                      i <
                      filteredStudents.length - 1
                        ? '1px solid var(--border)'
                        : 'none'
                  }}
                >

                  <td className="px-5 py-4 text-sm font-medium">
                    {s.name}
                  </td>

                  <td className="px-5 py-4 text-sm">
                    {s.email}
                  </td>

                  {/* MULTIPLE COURSES */}
                  <td className="px-5 py-4 text-sm">
  {s.course_names || '—'}
</td>

<td className="px-5 py-4 text-sm">
  {s.group_names || '—'}
</td>

                  <td className="px-5 py-4">

                    <button
                      onClick={() => {
  setForm({
    name: s.name,
    email: s.email,
    password: '',
    group_ids: s.group_ids
      ? s.group_ids.split(',')
      : []
  })

  setModal({
    mode: 'edit',
    student: s
  })
}}
                      className="text-xs px-3 py-1.5 rounded-lg mr-2"
                      style={{
                        background:
                          'var(--secondary)',
                        border:
                          '1px solid var(--border)'
                      }}
                    >
                      View / Edit
                    </button>

                    <button
                      onClick={() => remove(s)}
                      className="text-xs px-3 py-1.5 rounded-lg"
                      style={{
                        background: '#FEE2E2',
                        color: '#B91C1C',
                        border: 'none'
                      }}
                    >
                      Delete
                    </button>

                  </td>
                </tr>
              )
            )}
          </tbody>

        </table>
      </div>

      {/* MODAL */}
      {modal && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50"
          style={{
            background: 'rgba(0,0,0,.4)'
          }}
        >
          <div
            className="rounded-xl p-6 w-full max-w-sm"
            style={{
              background: 'var(--card)',
              border: '1px solid var(--border)'
            }}
          >

            <h2 className="text-lg font-semibold mb-5">
              {modal.mode === 'add'
                ? 'Add Student'
                : 'Edit Student'}
            </h2>

            <div className="space-y-3">

              <input
                value={form.name}
                onChange={(e) =>
                  setForm({
                    ...form,
                    name: e.target.value
                  })
                }
                placeholder="Full name"
                className="w-full px-3 py-2.5 rounded-lg text-sm"
                style={{
                  border:
                    '1px solid var(--border)',
                  background:
                    'var(--muted)'
                }}
              />

              <input
                value={form.email}
                onChange={(e) =>
                  setForm({
                    ...form,
                    email: e.target.value
                  })
                }
                placeholder="Email"
                type="email"
                className="w-full px-3 py-2.5 rounded-lg text-sm"
                style={{
                  border:
                    '1px solid var(--border)',
                  background:
                    'var(--muted)'
                }}
              />

              <input
                value={form.password}
                onChange={(e) =>
                  setForm({
                    ...form,
                    password: e.target.value
                  })
                }
                placeholder={
                  modal.mode === 'add'
                    ? 'Temporary password'
                    : 'New password (optional)'
                }
                type="text"
                className="w-full px-3 py-2.5 rounded-lg text-sm"
                style={{
                  border:
                    '1px solid var(--border)',
                  background:
                    'var(--muted)'
                }}
              />

              <div>
  <label
    className="block text-sm font-medium mb-2"
  >
    Groups
  </label>

  <select
    multiple
    value={form.group_ids}
    onChange={e => {
      const selectedGroups = Array.from(
        e.target.selectedOptions,
        option => option.value
      )

      setForm({
        ...form,
        group_ids: selectedGroups
      })
    }}
    className="w-full px-3 py-2.5 rounded-lg text-sm"
    style={{
      border: '1px solid var(--border)',
      background: 'var(--muted)',
      minHeight: '140px'
    }}
  >
    {groups.map(g => {
      const course = courses.find(
        c => Number(c.id) === Number(g.course_id)
      )

      return (
        <option
          key={g.id}
          value={String(g.id)}
        >
          {g.name}
          {course ? ` — ${course.name}` : ''}
        </option>
      )
    })}
  </select>

  <p
    className="text-xs mt-1"
    style={{
      color: 'var(--muted-foreground)'
    }}
  >
    Hold Ctrl (Windows) or Command (Mac) to select
    multiple groups.
  </p>
</div>

            </div>

            <div className="flex gap-3 mt-6">

              <button
                onClick={() =>
                  setModal(null)
                }
                className="flex-1 py-2.5 rounded-lg"
                style={{
                  border:
                    '1px solid var(--border)'
                }}
              >
                Cancel
              </button>

              <button
                onClick={save}
                className="flex-1 py-2.5 rounded-lg font-semibold"
                style={{
                  background:
                    'var(--primary)',
                  color: 'white',
                  border: 'none'
                }}
              >
                Save
              </button>

            </div>

          </div>
        </div>
      )}

    </div>
  )
}