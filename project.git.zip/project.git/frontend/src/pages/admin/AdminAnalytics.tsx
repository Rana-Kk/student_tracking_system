import { useEffect, useMemo, useState } from 'react'
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts'

import {
  getAnalyticsOverview,
  getGroupAnalytics,
} from '../../lib/api'

type GroupAnalyticsRow = {
  group?: string
  group_name?: string
  name?: string
  attendance?: number | string | null
  attendance_percentage?: number | string | null
  attendancePercent?: number | string | null
  quizAvg?: number | string | null
  quiz_avg?: number | string | null
  quiz_average?: number | string | null
  courseProgress?: number | string | null
  course_progress?: number | string | null
  progress?: number | string | null
  score?: number | string | null
  average_score?: number | string | null
  [key: string]: any
}

type TrendRow = {
  week?: string
  date?: string
  period?: string
  score?: number | string | null
  average_score?: number | string | null
  averageScore?: number | string | null
  [key: string]: any
}

function toNumber(value: unknown): number {
  const n = Number(value)
  return Number.isFinite(n) ? n : 0
}

function getData(response: any): any {
  if (Array.isArray(response)) return response
  if (Array.isArray(response?.data)) return response.data
  if (response?.data && typeof response.data === 'object') {
    return response.data
  }
  return response
}

function getGroupName(row: GroupAnalyticsRow): string {
  return (
    row.group_name ||
    row.group ||
    row.name ||
    `Group #${row.id ?? ''}`
  )
}

function getAttendance(row: GroupAnalyticsRow): number {
  return toNumber(
    row.attendance ??
    row.attendance_percentage ??
    row.attendancePercent
  )
}

function getQuizAverage(row: GroupAnalyticsRow): number {
  return toNumber(
    row.quizAvg ??
    row.quiz_avg ??
    row.quiz_average
  )
}


function getProgress(row: GroupAnalyticsRow): number {
  return toNumber(
    row.courseProgress ??
    row.course_progress ??
    row.progress ??
    row.average_score
  )
}

export default function AdminAnalytics() {
  const [groups, setGroups] = useState<GroupAnalyticsRow[]>([])
  const [trend, setTrend] = useState<TrendRow[]>([])

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    loadAnalytics()
  }, [])

  async function loadAnalytics() {
    try {
      setLoading(true)
      setError('')

      const [overviewResponse, groupsResponse] =
        await Promise.all([
          getAnalyticsOverview(),
          getGroupAnalytics(),
        ])

      /*
       * Group analytics
       */
      const groupsData = getData(groupsResponse)

      if (Array.isArray(groupsData)) {
        setGroups(groupsData)
      } else if (Array.isArray(groupsData?.groups)) {
        setGroups(groupsData.groups)
      } else {
        setGroups([])
      }

            const overviewData = getData(overviewResponse)

      let trendData: any[] = []

      if (Array.isArray(overviewData)) {
        trendData = overviewData
      } else if (Array.isArray(overviewData?.trend)) {
        trendData = overviewData.trend
      } else if (Array.isArray(overviewData?.progress)) {
        trendData = overviewData.progress
      } else if (Array.isArray(overviewData?.progress_trend)) {
        trendData = overviewData.progress_trend
      } else if (Array.isArray(overviewData?.progressTrend)) {
        trendData = overviewData.progressTrend
      }

      setTrend(trendData)
    } catch (err: any) {
      setError(
        err?.message ||
        'Could not load analytics data.'
      )
    } finally {
      setLoading(false)
    }
  }

  const groupChartData = useMemo(() => {
    return groups.map((row) => ({
      group: getGroupName(row),
      attendance: getAttendance(row),
      quizAvg: getQuizAverage(row),
    }))
  }, [groups])

  const trendChartData = useMemo(() => {
    return trend.map((row, index) => ({
      week:
        row.week ||
        row.period ||
        row.date ||
        `Period ${index + 1}`,

      score: toNumber(
        row.score ??
        row.average_score ??
        row.averageScore
      ),
    }))
  }, [trend])

  /*
   * Overall statistics calculated from the real group data.
   */
  const summary = useMemo(() => {
    if (!groups.length) {
      return {
        attendance: 0,
        quiz: 0,
        progress: 0,
      }
    }

    const average = (
      values: number[]
    ) =>
      values.length
        ? Math.round(
            values.reduce(
              (sum, value) => sum + value,
              0
            ) / values.length
          )
        : 0

    return {
      attendance: average(
        groups.map(getAttendance)
      ),
      quiz: average(
        groups.map(getQuizAverage)
      ),
      progress: average(
        groups.map(getProgress)
      ),
    }
  }, [groups])

  return (
    <div className="p-6 max-w-5xl mx-auto">

      {/* Header */}
      <div className="mb-6">
        <h1
          className="text-2xl font-semibold"
          style={{
            fontFamily:
              'Outfit, sans-serif',
          }}
        >
          Analytics
        </h1>

        <p
          className="text-sm mt-0.5"
          style={{
            color:
              'var(--muted-foreground)',
          }}
        >
          Organisation-wide performance
          metrics
        </p>
      </div>

      {/* Error */}
      {error && (
        <div
          className="mb-5 rounded-lg px-4 py-3 text-sm"
          style={{
            background: '#FEE2E2',
            color: '#B91C1C',
          }}
        >
          {error}
        </div>
      )}

      {loading ? (
        <div
          className="rounded-xl p-10 text-center"
          style={{
            background: 'var(--card)',
            border:
              '1px solid var(--border)',
          }}
        >
          <p
            className="text-sm"
            style={{
              color:
                'var(--muted-foreground)',
            }}
          >
            Loading analytics…
          </p>
        </div>
      ) : (
        <div className="grid gap-6">

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {([['Attendance', summary.attendance], ['Avg. Quiz Score', summary.quiz], ['Course Progress', summary.progress]] as const).map(([label, value]) => (
              <div key={label} className="rounded-xl p-4" style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
                <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{label}</p>
                <p className="text-2xl font-semibold mono mt-1">{value}%</p>
              </div>
            ))}
          </div>

          <div
            className="rounded-xl p-5"
            style={{
              background: 'var(--card)',
              border:
                '1px solid var(--border)',
            }}
          >
            <h2
              className="text-base font-semibold mb-4"
              style={{
                fontFamily:
                  'Outfit, sans-serif',
              }}
            >
              Group Comparison
            </h2>

            {groupChartData.length === 0 ? (
              <div className="py-16 text-center">
                <p
                  className="text-sm"
                  style={{
                    color:
                      'var(--muted-foreground)',
                  }}
                >
                  No group analytics data
                  available yet.
                </p>
              </div>
            ) : (
              <ResponsiveContainer
                width="100%"
                height={280}
              >
                <BarChart
                  data={groupChartData}
                  barCategoryGap="30%"
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="var(--border)"
                    vertical={false}
                  />

                  <XAxis
                    dataKey="group"
                    tick={{
                      fontSize: 12,
                      fill: '#64748B',
                      fontFamily:
                        'DM Mono, monospace',
                    }}
                    axisLine={false}
                    tickLine={false}
                  />

                  <YAxis
                    domain={[0, 100]}
                    tick={{
                      fontSize: 11,
                      fill: '#64748B',
                    }}
                    axisLine={false}
                    tickLine={false}
                    width={32}
                  />

                  <Tooltip
                    contentStyle={{
                      borderRadius: '8px',
                      border:
                        '1px solid var(--border)',
                      fontSize: '12px',
                    }}
                  />

                  <Legend
                    wrapperStyle={{
                      fontSize: '12px',
                      paddingTop: '12px',
                    }}
                  />

                  <Bar
                    dataKey="attendance"
                    name="Attendance %"
                    fill="#1D4ED8"
                    radius={[
                      4,
                      4,
                      0,
                      0,
                    ]}
                  />

                  <Bar
                    dataKey="quizAvg"
                    name="Quiz Avg %"
                    fill="#0891B2"
                    radius={[
                      4,
                      4,
                      0,
                      0,
                    ]}
                  />

                </BarChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* Progress trend */}
          <div
            className="rounded-xl p-5"
            style={{
              background: 'var(--card)',
              border:
                '1px solid var(--border)',
            }}
          >
            <h2
              className="text-base font-semibold mb-4"
              style={{
                fontFamily:
                  'Outfit, sans-serif',
              }}
            >
              Average Score Trend
            </h2>

            {trendChartData.length === 0 ? (
              <div className="py-16 text-center">
                <p
                  className="text-sm"
                  style={{
                    color:
                      'var(--muted-foreground)',
                  }}
                >
                  No progress trend data
                  available yet.
                </p>
              </div>
            ) : (
              <ResponsiveContainer
                width="100%"
                height={220}
              >
                <LineChart
                  data={trendChartData}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="var(--border)"
                    vertical={false}
                  />

                  <XAxis
                    dataKey="week"
                    tick={{
                      fontSize: 12,
                      fill: '#64748B',
                      fontFamily:
                        'DM Mono, monospace',
                    }}
                    axisLine={false}
                    tickLine={false}
                  />

                  <YAxis
                    domain={[0, 100]}
                    tick={{
                      fontSize: 11,
                      fill: '#64748B',
                    }}
                    axisLine={false}
                    tickLine={false}
                    width={32}
                  />

                  <Tooltip
                    contentStyle={{
                      borderRadius: '8px',
                      border:
                        '1px solid var(--border)',
                      fontSize: '12px',
                    }}
                  />

                  <Line
                    type="monotone"
                    dataKey="score"
                    name="Score %"
                    stroke="#1D4ED8"
                    strokeWidth={2}
                    dot={{
                      r: 4,
                      fill: '#1D4ED8',
                      strokeWidth: 2,
                      stroke: 'white',
                    }}
                    activeDot={{
                      r: 6,
                    }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>

        </div>
      )}
    </div>
  )
}