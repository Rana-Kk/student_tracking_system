import express from 'express'
import cors from 'cors'
import authRoutes from './routes/auth.routes.js'
import coursesRoutes from './routes/courses.routes.js'
import groupsRoutes from './routes/groups.routes.js'
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js'

export const app = express()

app.use(cors())
app.use(express.json())

app.get('/health', (req, res) => res.json({ status: 'ok' }))

app.use('/api/auth', authRoutes)
app.use('/api/courses', coursesRoutes)
app.use('/api/groups', groupsRoutes)

// New resources (assessments, submissions, ai-evaluations, quizzes, ...) get
// added here following the same pattern: routes/x.routes.js -> controllers/x.controller.js

app.use(notFoundHandler)
app.use(errorHandler) // must be last
