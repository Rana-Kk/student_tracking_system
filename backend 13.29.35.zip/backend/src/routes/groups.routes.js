import { Router } from 'express'
import {
  listGroups,
  getGroup,
  createGroup,
  assignTeacher,
  addStudent,
  listGroupStudents,
} from '../controllers/groups.controller.js'
import { authenticate, requireRole } from '../middleware/auth.js'

const router = Router()

router.use(authenticate)

router.get('/', listGroups)
router.get('/:id', getGroup)
router.get('/:id/students', listGroupStudents)

router.post('/', requireRole('admin'), createGroup)
router.post('/:id/teachers', requireRole('admin'), assignTeacher)
router.post('/:id/students', requireRole('admin'), addStudent)

export default router
