import jwt from 'jsonwebtoken'
import { ApiError } from '../utils/ApiError.js'

// Verifies the Bearer token and attaches { id, role } to req.user.
// Every route below this middleware can assume req.user exists.
export function authenticate(req, res, next) {
  const header = req.headers.authorization || ''
  const token = header.startsWith('Bearer ') ? header.slice(7) : null

  if (!token) {
    return next(new ApiError(401, 'Missing or invalid Authorization header'))
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET)
    req.user = { id: payload.sub, role: payload.role }
    next()
  } catch {
    next(new ApiError(401, 'Invalid or expired token'))
  }
}

// Usage: router.post('/', authenticate, requireRole('admin'), controller)
// Usage: router.post('/', authenticate, requireRole('admin', 'teacher'), controller)
export function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user || !allowedRoles.includes(req.user.role)) {
      return next(new ApiError(403, 'You do not have permission to perform this action'))
    }
    next()
  }
}
